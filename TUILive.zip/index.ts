import LiveMainView from './liveMainView.vue';
import PreLiveView from './preLiveView.vue';
import TUIRoomEngine from '@tencentcloud/tuiroom-engine-js';
import {
  liveRoom,
  RoomEvent,
  FeatureButton,
  ThemeOption,
} from './live';
import { roomService } from './services';
import { App } from "vue";
export * from './components/common/base/index';
export * from './services/manager/configManager';
export {
  LiveMainView,
  PreLiveView,
  TUIRoomEngine,
  roomService,
  liveRoom,
  RoomEvent,
  FeatureButton,
};
export type { ThemeOption };

LiveMainView.install = (app: App) => {
  app.component('LiveMainView', LiveMainView);
};

export default LiveMainView;
