export const animationUrlReplaceTarget = 'http://dldir1.qq.com/hudongzhibo/TRTC/TUIKit';

export const animationUrlReplaceContent = 'https://web.sdk.qcloud.com/trtc/live/assets';

export const SingleRechargeAmount = 300;

export const AccountMoneyLimit = 10000;