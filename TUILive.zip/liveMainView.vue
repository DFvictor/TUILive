<template>
  <loading-overlay v-if="isShowLoading" />
  <div v-else id="liveContainer" ref="roomRef" class="tui-live-container">
    <div class="live-header">
      <img class="logo" src="./assets/imgs/logo.png" alt="logo">
      <user-info
        class="user-info"
        :user-id="userInfo.userId"
        :user-name="userInfo.userName || userInfo.userId"
        :avatar-url="userInfo.avatarUrl"
        @log-out="logout"
      />
      <div class="top-right-operator-h5">
        <AudienceListH5 />
        <SvgIcon class="svg-icon" :icon="CloseIcon" @click="leaveRoom"/>
      </div>
    </div>
    <div class="live-body">
      <div class="live-content">
        <anchor-info class="anchor-info-area" />
        <room-content
          ref="roomContentRef"
          v-tap.lazy="handleRoomContentTap"
          class="tui-live-stream-content"
        />
        <div v-if="isAudience" class="tui-live-gift-area" v-click-outside="handleClickOutside">
          <GiftList class="gift-list" :class="isDisplayGiftList ? 'display-gift-list-h5' : ''"/>
          <GiftListPopupPC :class="['gift-list-popup', { 'display-gift-list-popup': isDisplayGiftList }]"/>
          <GiftMore class="gift-more" @click="handleOpenMoreGiftList" />
        </div>
        <div v-if="isAnchor" class="tui-live-anchor-controls">
          <div class="live-audio-video-setting">
            <AudioSetting
              :displayMode = 'MediaSettingDisplayMode.Icon'
            />
            <VideoSetting 
              :displayMode = 'MediaSettingDisplayMode.Icon'
            />
          </div>
          <div class="live-end-live-button">
            <TUIButton
                size="big"
                type="primary"
                color="red"
                @click.stop="handleEndLiving"
              >
              {{ t('End Living') }}
            </TUIButton>
          </div>
        </div>
        <ShareLink class="tui-share-link-button" />
      </div>
      <div class="live-interactive">
        <div class="tui-live-audience-list" v-if="!isShowLoading">
          <AudienceList />
        </div>
        <div class="tui-live-chat">
          <chat />
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import {
  ref,
  onMounted,
  onUnmounted,
  Ref,
  watch,
  defineExpose,
  defineEmits,
  defineProps,
} from 'vue';
import RoomContent from './components/RoomContent/index.vue';
import Chat from './components/Chat/index.vue';
import { debounce, throttle } from './utils/utils';
import { isMobile, isWeChat } from './utils/environment';
import vTap from './directives/vTap';
import {
  TUIKickedOutOfRoomReason,
  TUIErrorCode,
  TUIRole
} from '@tencentcloud/tuiroom-engine-js';
import { IconClose, TUIButton } from '@tencentcloud/uikit-base-component-vue3';
import { useRoomStore } from './stores/room';
import { MESSAGE_DURATION } from './constants/message';
import UserInfo from './components/RoomHeader/UserInfo';
import LoadingOverlay from './components/PreRoom/LoadingOverlay.vue';
import TUIMessageBox from './components/common/base/MessageBox/index';
import TUIMessage from './components/common/base/Message/index';
import useTRTCDetect from './hooks/useTRTCDetect';
import AnchorInfo from './components/AnchorInfo/AnchorInfo.vue';
import AudienceList from './components/AudienceList/AudienceList.vue';
import AudienceListH5 from './components/AudienceList/AudienceListH5.vue';
import GiftList from './components/Gift/GiftList.vue';
import GiftListPopupPC from './components/Gift/GiftPopupList.vue';
import GiftMore from './components/Gift/GiftMore.vue';
import CloseIcon from './components/common/icons/CloseIcon.vue';
import ShareLink from './components/ShareLink/ShareLink.vue';
import AudioSetting from './core/components/AudioSetting/index.vue';
import VideoSetting from './core/components/VideoSetting/index.vue';
import {
  roomService,
  EventType,
  RoomParam,
  RoomInitData,
} from './services/index';
import useDeviceManager from './hooks/useDeviceManager';
import vClickOutside from './directives/vClickOutside';
import { createGiftCardManager } from './components/Gift/useGiftPlayerCard';
import { storeToRefs } from 'pinia';
import { MediaSettingDisplayMode } from './core';
const roomEngine = useRoomStore();
const { getUserRole } = roomEngine;
const { isAnchor, isAudience } = storeToRefs(roomEngine);
const isShowPasswordContainer = ref(false);
const isShowLoading = ref(true);
const isDisplayGiftList = ref(false);
const { userInfo } = defineProps<{
  userInfo: {
    userId: string;
    userName: string;
    avatarUrl: string;
  };
}>();

createGiftCardManager();
useTRTCDetect();
useDeviceManager({ listenForDeviceChange: true });

const { t } = roomService;
defineExpose({
  init,
  createRoom,
  enterRoom,
  dismissRoom,
  leaveRoom,
  resetStore,
  t,
});

const emit = defineEmits([
  'on-log-out',
  'on-create-room',
  'on-enter-room',
  'on-exit-room',
  'on-destroy-room',
  'on-kicked-out-of-room',
  'on-kicked-off-line',
  'on-userSig-expired',
]);

const handleOpenMoreGiftList = () => {
  isDisplayGiftList.value = !isDisplayGiftList.value;
}

const handleClickOutside = () => {
  isDisplayGiftList.value = false;
}

const handleEndLiving = () => {
  roomService.dismissRoom();
}

const showMessageBox = (data: {
  code?: number;
  message: string;
  title: string;
  duration?: number;
  cancelButtonText: string;
  confirmButtonText: string;
  callback?: () => void;
}) => {
  const {
    message,
    title = roomService.t('Note'),
    duration,
    cancelButtonText,
    confirmButtonText = roomService.t('Sure'),
    callback = () => {},
  } = data;
  TUIMessageBox({
    title,
    message,
    duration,
    cancelButtonText,
    confirmButtonText,
    callback,
  });
};
const showMessage = (data: {
  type: 'warning' | 'success' | 'error' | 'info';
  message: string;
  duration: MESSAGE_DURATION;
}) => {
  const { type, message, duration } = data;
  TUIMessage({
    type,
    message,
    duration,
  });
};

onMounted(() => {
  roomService.on(EventType.ROOM_NOTICE_MESSAGE, showMessage);
  roomService.on(EventType.ROOM_NOTICE_MESSAGE_BOX, showMessageBox);
  roomService.on(EventType.KICKED_OUT, onKickedOutOfRoom);
  roomService.on(EventType.USER_SIG_EXPIRED, onUserSigExpired);
  roomService.on(EventType.KICKED_OFFLINE, onKickedOffLine);
  roomService.on(EventType.ROOM_START, onStartRoom);
  roomService.on(EventType.ROOM_JOIN, onJoinRoom);
  roomService.on(EventType.ROOM_LEAVE, onLeaveRoom);
  roomService.on(EventType.ROOM_DISMISS, onDismissRoom);
  roomService.on(EventType.USER_LOGOUT, onLogout);
  roomService.on(EventType.ROOM_NEED_PASSWORD, onRoomNeedPassword);
});

onUnmounted(() => {
  roomService.off(EventType.ROOM_NOTICE_MESSAGE, showMessage);
  roomService.off(EventType.ROOM_NOTICE_MESSAGE_BOX, showMessageBox);
  roomService.off(EventType.KICKED_OUT, onKickedOutOfRoom);
  roomService.off(EventType.USER_SIG_EXPIRED, onUserSigExpired);
  roomService.off(EventType.KICKED_OFFLINE, onKickedOffLine);
  roomService.off(EventType.ROOM_START, onStartRoom);
  roomService.off(EventType.ROOM_JOIN, onJoinRoom);
  roomService.off(EventType.ROOM_LEAVE, onLeaveRoom);
  roomService.off(EventType.ROOM_DISMISS, onDismissRoom);
  roomService.off(EventType.USER_LOGOUT, onLogout);
  roomService.off(EventType.ROOM_NEED_PASSWORD, onRoomNeedPassword);
  roomService.resetStore();
});

/**
 * Handle page mouse hover display toolbar logic
 *
 **/
const roomContentRef = ref<InstanceType<typeof RoomContent>>();
const showRoomTool: Ref<boolean> = ref(true);
const roomRef: Ref<Node | undefined> = ref();
function handleHideRoomTool() {
  showRoomTool.value = false;
}

watch(
  () => roomRef.value,
  (newValue, oldValue) => {
    if (!isWeChat && !isMobile) {
      if (newValue) {
        addRoomContainerEvent(newValue);
      } else {
        oldValue && removeRoomContainerEvent(oldValue);
      }
    }
  }
);

const handleHideRoomToolDebounce = debounce(handleHideRoomTool, 5000);
const handleHideRoomToolThrottle = throttle(handleHideRoomToolDebounce, 1000);
const showTool = () => {
  showRoomTool.value = true;
  handleHideRoomToolDebounce();
};
const showToolThrottle = () => {
  showRoomTool.value = true;
  handleHideRoomToolThrottle();
};
const hideTool = () => {
  handleHideRoomTool();
};
const addRoomContainerEvent = (container: Node) => {
  container.addEventListener('mouseenter', showTool);
  container.addEventListener('click', showTool);
  container.addEventListener('mousemove', showToolThrottle);
  container.addEventListener('mouseleave', hideTool);
};
const removeRoomContainerEvent = (container: Node) => {
  container.removeEventListener('mouseenter', showTool);
  container.removeEventListener('click', showTool);
  container.removeEventListener('mousemove', showToolThrottle);
  container.removeEventListener('mouseleave', hideTool);
};

function handleRoomContentTap() {
  showRoomTool.value = !showRoomTool.value;
  if (showRoomTool.value) {
    handleHideRoomToolDebounce();
  }
}

async function dismissRoom() {
  await roomService.dismissRoom();
}

async function leaveRoom() {
  const userRole = getUserRole(userInfo.userId);
  if (userRole === TUIRole.kRoomOwner) {
    await roomService.dismissRoom();
  } else {
    await roomService.leaveRoom();
  }
}

async function init(option: RoomInitData) {
  await roomService.initRoomKit(option);
}

async function createRoom(options: {
  roomId: string;
  roomName: string;
  roomParam?: RoomParam;
}) {
  const { roomId, roomName, roomParam } = options;
  roomService.createRoom({
    roomId,
    roomName,
    roomParam,
  });
}

async function enterRoom(options: { roomId: string; roomParam?: RoomParam }) {
  await roomService.enterRoom(options);
}

function onRoomNeedPassword(code: TUIErrorCode) {
  if (code === TUIErrorCode.ERR_NEED_PASSWORD) {
    isShowPasswordContainer.value = true;
  }
}

function resetStore() {
  roomService.resetStore();
}

const logout = async () => {
  const userRole = getUserRole(userInfo.userId);
  if (userRole === TUIRole.kRoomOwner) {
    await roomService.dismissRoom();
  } else if (userRole === TUIRole.kGeneralUser) {
    await roomService.leaveRoom();
  }
  roomService.logout();
};

const onStartRoom = () => {
  isShowLoading.value = false;
  emit('on-create-room', { code: 0, message: 'create room' });
};

const onJoinRoom = () => {
  isShowLoading.value = false;
  isShowPasswordContainer.value = false;
  emit('on-enter-room', { code: 0, message: 'enter room' });
};

const onLeaveRoom = async () => {
  emit('on-exit-room', { code: 0, message: 'exit room' });
};

const onDismissRoom = () => {
  emit('on-destroy-room', { code: 0, message: 'destroy room' });
};

const onLogout = () => {
  emit('on-log-out', { code: 0, message: 'user logout' });
};

const onKickedOutOfRoom = async (eventInfo: {
  roomId: string;
  reason: TUIKickedOutOfRoomReason;
  message: string;
}) => {
  const { roomId, reason, message } = eventInfo;
  emit('on-kicked-out-of-room', { roomId, reason, message });
};

const onUserSigExpired = () => {
  emit('on-userSig-expired');
};

const onKickedOffLine = (eventInfo: { message: string }) => {
  const { message } = eventInfo;
  emit('on-kicked-off-line', { message });
};
</script>

<style lang="scss">
@import './assets/style/global.scss';
@import './assets/style/black-theme.scss';
@import './assets/style/white-theme.scss';
@import '@tencentcloud/uikit-base-component-vue3/dist/styles/index.css';

#app {
  color: rgba(255, 255, 255, 0.9);
}
</style>

<style lang="scss" scoped>
@import './assets/style/variables.scss';

@media screen and (width >= $h5Breakpoint) {
  .tui-live-container {
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    padding: 1rem;
    background-color: #000000;

    .live-header {
      display: flex;
      justify-content: space-between;
      height: 3rem;

      .logo {
        width: 5.5rem;
        height: 1.5rem;
        -webkit-user-drag: none;
      }

      .top-right-operator-h5 {
        display: none;
      }

      .user-info {
        display: block;
        height: 100%;
        z-index: $levelTwoZIndex;
      }
    }


    .live-body {
      display: flex;
      flex: 1;
      height: calc(100% - 3rem);
      border-radius: 1rem;
      overflow: hidden;

      .live-content {
        display: flex;
        flex-direction: column;
        position: relative;
        flex-grow: 1;
        width: 75%;
        height: 100%;
        background-color: #1F2024;

        .tui-live-stream-content {
          flex: 1;
          width: 100%;
          margin-bottom: 0.5rem;
        }

        .anchor-info-area {
          width: 100%;
          margin: 1rem 0;
          padding-left: 1rem;
        }

        .tui-live-gift-area {
          position: relative;
          display: flex;
          flex-shrink: 0;
          width: 100%;
          height: 15%;

          .gift-list-popup {
            position: absolute;
            display: none;
            right: 0;
            top: 0;
            transform: translate(30%, -110%);
            width: 35.5rem;
            height: 28rem;
            overflow: hidden;
            z-index: $topLayerZIndex;
          }

          .display-gift-list-popup{
            display: block;
          }
        }

        .tui-live-anchor-controls {
          display: flex;
          align-items: center;
          justify-content: space-between;
          
          .live-audio-video-setting {
            --font-color-1: #ccc8c8;
            display: flex;
            padding: 1rem;
          }

          .live-end-live-button {
            margin-right: 1.5rem;
          }
        }



        .tui-share-link-button {
          display: none;
        }
      }

      .live-interactive {
        display: flex;
        flex-direction: column;
        flex-grow: 1;
        position: relative;
        width: 25%;
        height: 100%;
        overflow: hidden;
        background-color: #000000;
        margin-left: 0.5rem;

        .tui-live-audience-list {
          flex-shrink: 0;
          width: 100%;
          height: 35%;
        }

        .tui-live-chat {
          margin-top: 0.5rem;
          width: 100%;
          height: calc(65% - 0.5rem);
        }
      }
    }
  }
}

@media screen and (width < $h5Breakpoint) {
  .logo,.gift-list-popup,.user-info {
    display: none;
  }
  .top-right-operator-h5 {
    display: flex;
    justify-content: center;
    align-items: center;
    position: absolute;
    top: $headerPositionTop;
    right: 2.5rem;
    width: 5rem;
    z-index: $levelTwoZIndex;

    .svg-icon {
      position: absolute;
      right: -1.5rem;
      width: 1.5rem;
      height: 1.5rem;
      cursor: pointer;
    }
  }

  .live-body {
    height: 100%;

    .live-content {
      background-color: #1F2024;
    }

    .gift-list {
      position: relative;
      display: flex;
      flex-wrap: wrap;
      width: 100%;
      height: 0;
      transition: height $popupTransitionTime;
      z-index: $levelTwoZIndex;
    }

    .gift-list.display-gift-list-h5 {
      position: relative;
      height: 20.75rem;
    }
  }

  @media screen  and (orientation: portrait) {
    .tui-live-container {
      display: flex;
      width: 100%;
      height: 100%;
      flex-direction: column;
      background-color: #30313a;

      .live-body {
        display: flex;
        flex-direction: column;

        .live-content {
          display: flex;
          align-items: end;
          justify-content: center;
          width: 100%;
          height: 100%;

          .anchor-info-area {
            position: absolute;
            left: 1rem;
            top: 1rem;
          }

          .tui-live-stream-content {
            width: 100%;
            height: 100%;
          }

          .tui-live-gift-area {
            position: absolute;
            width: 100%;
            z-index: $levelOneZIndex;

            .gift-more {
              position: absolute;
              bottom: 1.5rem;
              right: 3rem;
              cursor: pointer;
              z-index: $levelOneZIndex;
            }
          }

          .tui-live-anchor-controls {
            display: none;
          }

          .tui-share-link-button {
            position: absolute;
            bottom: 1.5rem;
            right: 0.5rem;
            z-index: $levelZeroZIndex;
          }
        }

        .live-interactive {
          display: flex;
          flex-direction: column;
          flex: 1;
          position: relative;
          width: 100%;

          .tui-live-audience-list {
            display: none;
          }
          
          .tui-live-chat {
            position: absolute;
            bottom: 0.75rem;
            width: 90vw;
            height: 40vh;
            background-color: transparent;
          }
        }
      }


    }
  }

  @media screen  and (orientation: landscape) {
    .tui-live-container {
      display: flex;
      width: 100%;
      height: 100%;
      flex-direction: column;
      background-color: #000000;

      .live-content {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;

        .anchor-info-area {
          position: absolute;
          left: 0.5rem;
          top: 0.5rem;
        }

        .tui-live-stream-content {
          width: 85%;
          height: 100%;
        }


        .tui-live-gift-area {
          display: flex;
          position: absolute;
          left: 0;
          bottom: 0;
          width: 100%;
          z-index: $levelOneZIndex;

          .gift-more {
            position: absolute;
            bottom: 1.5rem;
            right: 3.5rem;
            cursor: pointer;
            z-index: $levelOneZIndex;
          }
        }

        .tui-share-link-button {
            position: absolute;
            bottom: 1.5rem;
            right: 1rem;
            cursor: pointer;
            z-index: $levelZeroZIndex;
          }

        .tui-live-anchor-controls {
          display: none;
        }
      }

      .live-interactive {
        position: absolute;
        bottom: 0;
        width: 40%;
        height: 80%;
        background-color: transparent;

        .tui-live-audience-list {
          display: none;
        }
        .tui-live-chat {
          position: absolute;
          bottom: 0.5rem;
          width: 90vw;
          height: 50vh;
          background-color: transparent;
        }
      }
    }
  }
}
</style>