import useRoomActions from './useRoomActions';

export default function useRoomState() {
  return {
    useRoomActions,
  };
}
