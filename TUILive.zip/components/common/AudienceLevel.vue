<template>
  <span ref='audienceLevelElement' class='audience-level'>
    <SvgIcon class='svg-icon' :icon='DiamondIcon' />
    <span>{{ props.level }}</span>
  </span>
</template>

<script setup lang="ts">
import { ref, defineProps, onMounted, watch } from 'vue';
import SvgIcon from './base/SvgIcon.vue';
import DiamondIcon from './icons/DiamondIcon.vue';

const audienceLevelElement= ref<HTMLElement | null>(null);

interface Props {
  level: number;
}
const props = defineProps<Props>();

const colorLevelMap = {
  color_level_1: '#008FB2',
  color_level_2: '#2B6AD6',
  color_level_3: '#693CF0',
  color_level_4: '#C22F56',
}

const getLevelColor = (level: number) => {
  if (level >= 0 && level < 25) {
    return colorLevelMap.color_level_1;
  } else if (level >= 25 && level < 50) {
    return colorLevelMap.color_level_2;
  } else if (level >= 50 && level < 75) {
    return colorLevelMap.color_level_3;
  } else if (level >= 75 && level < 100) {
    return colorLevelMap.color_level_4;
  } else {
    return colorLevelMap.color_level_1;
  }
};

const updateBackgroundColor = (level: number) => { 
  if (!audienceLevelElement.value) return;
  audienceLevelElement.value.style.setProperty('background-color', getLevelColor(level));
};

watch(() => props.level, () => {
  updateBackgroundColor(props.level);
}, { immediate: true });

onMounted(() => {
  updateBackgroundColor(props.level);
})

</script>

<style lang="scss" scoped>
.audience-level {
  display: flex;
  flex-shrink: 0;
  justify-content: center;
  align-items: center;
  height: 1.125rem;
  width: 2.25rem;
  border-radius: 1rem;
  line-height: 1.125rem;
  font-size: 0.5rem;
  color: #FFFFFF;
  background-color: #1890ff;

  .svg-icon {
    margin-right: 0.125rem;
  }

  span {
    display: inline-block;
    height: 100%;
    font-size: 0.75rem;
  }
}
</style>
