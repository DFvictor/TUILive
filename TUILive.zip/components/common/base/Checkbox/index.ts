import CheckboxPC from './CheckboxPC.vue';
const Checkbox = CheckboxPC;
export default Checkbox;
