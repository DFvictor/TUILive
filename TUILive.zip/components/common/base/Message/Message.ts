import createInstance, { MessageProps } from './Instance';

const renderMsg = (config: MessageProps) => createInstance(config);

export default renderMsg;
