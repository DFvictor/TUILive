<template>
  <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path
      d="M11.5 4.5L13.5 4.5C14.0523 4.5 14.5 4.94772 14.5 5.5V12C14.5 12.5523 14.0523 13 13.5 13H2.5C1.94772 13 1.5 12.5523 1.5 12V3C1.5 2.44771 1.94772 2 2.5 2H10.5C11.0523 2 11.5 2.44771 11.5 3V4.5ZM10.5 3L2.5 3V4.5L10.5 4.5V3ZM13.5 5.5H2.5L2.5 12H13.5V5.5Z"
      fill="currentColor" fill-opacity="0.9" />
  </svg>
</template>