<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M7 0H9V16H7V0ZM6 8L0 13V3L6 8ZM10 8L16 3V13L10 8Z"
      fill="currentColor"
    />
  </svg>
</template>
