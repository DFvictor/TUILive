<template>
  <svg
    width="30"
    height="30"
    viewBox="0 0 30 30"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 48097289">
      <path
        id="Ellipse 349"
        d="M27 15C27 21.6274 21.6274 27 15 27C8.37258 27 3 21.6274 3 15C3 12.1605 3.98496 9.55384 5.63267 7.49904C6.3356 6.62243 7.159 5.84657 8.07758 5.19665C10.0333 3.81292 12.4202 3 15 3C21.6274 3 27 8.37258 27 15Z"
        stroke="#4F586B"
        stroke-width="2"
      />
      <path
        id="Ellipse 352"
        d="M18 17C18 18.6569 16.6569 20 15 20C13.3431 20 12 18.6569 12 17"
        stroke="#4F586B"
        stroke-width="2"
      />
      <path id="Vector 195" d="M8 11L6 15" stroke="#4F586B" stroke-width="2" />
      <path
        id="Vector 197"
        d="M20 11L18 15"
        stroke="#4F586B"
        stroke-width="2"
      />
      <path
        id="Vector 196"
        d="M12 11L10 15"
        stroke="#4F586B"
        stroke-width="2"
      />
      <path
        id="Vector 198"
        d="M24 11L22 15"
        stroke="#4F586B"
        stroke-width="2"
      />
    </g>
  </svg>
</template>
