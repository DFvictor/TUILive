<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M1 5C1 4.44772 1.44772 4 2 4H16C16.5523 4 17 4.44772 17 5V7.7288L21.5859 5.6431C22.248 5.34196 22.9999 5.82599 22.9999 6.55338V17.4466C22.9999 18.174 22.248 18.658 21.5859 18.3569L17 16.2712V19C17 19.5523 16.5523 20 16 20H2C1.44772 20 1 19.5523 1 19V5ZM2.7 18.3V5.7H15.3V18.3H2.7ZM17.0043 9.59439L21.2999 7.64074V16.3593L17.0043 14.4056V9.59439Z"
      fill="currentColor"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M8.50007 9.85H5.00007V8.15H8.50007V9.85Z"
      style="fill: var(--active-color-2); fill-opacity: 1"
    />
  </svg>
</template>
