<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="14"
    height="9"
    viewBox="0 0 14 9"
    fill="none"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.74219 0L11.4922 4.5L7.74219 9H10.0853L13.3551 5.07617L13.8353 4.5L13.3551 3.92383L10.0853 0H7.74219Z"
      fill="currentColor"
      style="fill-opacity: 1"
    />
    <path
      d="M7.16406 4.5H0.164062"
      stroke="currentColor"
      style="stroke-opacity: 1"
      stroke-width="1.8"
    />
  </svg>
</template>
