<template>
  <svg
    width="24"
    height="24"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 32 32"
    class="design-iconfont"
  >
    <g fill="currentColor" fill-rule="evenodd">
      <path
        d="M16,4 C9.372583,4 4,9.372583 4,16 C4,22.627417 9.372583,28 16,28 C22.627417,28 28,22.627417 28,16 C28,9.372583 22.627417,4 16,4 Z M16,6 C21.5228475,6 26,10.4771525 26,16 C26,21.5228475 21.5228475,26 16,26 C10.4771525,26 6,21.5228475 6,16 C6,10.4771525 10.4771525,6 16,6 Z"
        fill-rule="nonzero"
      />
      <path
        d="M1.5 0A1.5 1.5 0 1 0 1.5 3A1.5 1.5 0 1 0 1.5 0Z"
        transform="translate(8.5 14.5)"
      />
      <path
        d="M7.5 0A1.5 1.5 0 1 0 7.5 3A1.5 1.5 0 1 0 7.5 0Z"
        transform="translate(8.5 14.5)"
      />
      <path
        d="M13.5 0A1.5 1.5 0 1 0 13.5 3A1.5 1.5 0 1 0 13.5 0Z"
        transform="translate(8.5 14.5)"
      />
    </g>
  </svg>
</template>
