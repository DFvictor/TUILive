<template>
  <svg
    width="32"
    height="32"
    viewBox="0 0 32 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <!-- eslint-disable vue/no-parsing-error -->
    <g id="&#231;&#163;&#168;&#231;&#154;&#174;">
      <g id="Group 48097291">
        <g id="Group 48097256">
          <circle
            id="Ellipse 348"
            cx="16"
            cy="16"
            r="11.8"
            stroke="#4F586B"
            stroke-width="2"
          />
          <path
            id="Vector 187"
            d="M16 1.06665V30.9333"
            stroke="#4F586B"
            stroke-width="2"
          />
          <path
            id="Vector 190"
            d="M16 16H27.7333"
            stroke="#4F586B"
            stroke-width="2"
          />
          <path
            id="Vector 191"
            d="M16 10.6666H26.6667"
            stroke="#4F586B"
            stroke-width="2"
          />
          <path
            id="Vector 192"
            d="M16 21.3333H26.6667"
            stroke="#4F586B"
            stroke-width="2"
          />
        </g>
      </g>
    </g>
  </svg>
</template>
