<template>
  <svg
    width="18"
    height="19"
    viewBox="0 0 18 19"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M12 2.5H6L6 0.25H4.5L4.5 2.5H1.5C0.671573 2.5 0 3.17157 0 4V17.5C0 18.3284 0.671573 19 1.5 19H16.5C17.3284 19 18 18.3284 18 17.5V4C18 3.17157 17.3284 2.5 16.5 2.5H13.5V0.25H12L12 2.5ZM4.5 5.5L6 5.5V4H12L12 5.5L13.5 5.5V4H16.5V7H1.5V4H4.5L4.5 5.5ZM1.5 8.5H16.5V17.5H1.5L1.5 8.5Z"
      fill="currentColor"
    />
  </svg>
</template>
