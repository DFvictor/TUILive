<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="8"
    height="12"
    viewBox="0 0 8 12"
    fill="none"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.78516 0.932617L3.5621 6.00028L7.78516 11.0679L4.43791 11.0679L0.900766 6.82337L0.214854 6.00028L0.900766 5.17718L4.43791 0.932617L7.78516 0.932617Z"
      fill="currentColor"
    />
  </svg>
</template>
