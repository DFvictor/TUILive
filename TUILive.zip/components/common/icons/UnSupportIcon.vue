<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="14"
    height="14"
    viewBox="0 0 14 14"
    fill="none"
  >
    <circle
      cx="7.00781"
      cy="7"
      r="7"
      fill="#FF643D"
      style="
        fill: #ff643d;
        fill: color(display-p3 1 0.3922 0.2392);
        fill-opacity: 1;
      "
    />
    <path
      d="M10 3.99989L3.99936 10.0005"
      stroke="white"
      style="stroke: white; stroke-opacity: 1"
      stroke-width="1.5"
    />
    <path
      d="M4 3.99989L10.0006 10.0005"
      stroke="white"
      style="stroke: white; stroke-opacity: 1"
      stroke-width="1.5"
    />
  </svg>
</template>
