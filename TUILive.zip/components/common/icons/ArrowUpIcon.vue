<template>
  <svg
    width="12"
    height="12"
    viewBox="0 0 12 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M1.56473 8.20938L5.59313 2.56961C5.79254 2.29044 6.20746 2.29044 6.40687 2.56961L10.4353 8.20938C10.6717 8.54032 10.4351 9 10.0284 9H1.97159C1.56491 9 1.32835 8.54032 1.56473 8.20938Z"
      fill="currentColor"
    />
  </svg>
</template>
