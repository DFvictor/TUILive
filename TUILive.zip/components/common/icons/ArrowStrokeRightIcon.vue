<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 7815">
      <path
        id="Union"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12.3935 8L8.64345 3.5H10.8564L14.1529 7.45584L14.6064 8L14.1529 8.54416L10.8564 12.5H8.64345L12.3935 8ZM8 7.15H1V8.85H8V7.15Z"
        fill="currentColor"
      />
    </g>
  </svg>
</template>
