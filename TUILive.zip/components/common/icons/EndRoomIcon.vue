<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 48096891">
      <path
        id="Rectangle 18576"
        d="M17 4.5V4C17 3.44772 16.5523 3 16 3H4C3.44772 3 3 3.44772 3 4V16C3 16.5523 3.44772 17 4 17H16C16.5523 17 17 16.5523 17 16V15.5"
        stroke="#ED414D"
        stroke-width="1.5"
      />
      <g id="Group 48096890">
        <path
          id="Vector 166"
          d="M7 10L16 10"
          stroke="#ED414D"
          stroke-width="1.5"
        />
        <path
          id="Polygon 8"
          d="M13 14L16.2929 10.7071C16.6834 10.3166 16.6834 9.68342 16.2929 9.29289L13 6"
          stroke="#ED414D"
          stroke-width="1.5"
        />
      </g>
    </g>
  </svg>
</template>
