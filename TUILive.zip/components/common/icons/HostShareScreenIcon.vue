<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 16 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="design-iconfont"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M5.84823 10.4236C2.98532 10.5677 0.708374 12.9346 0.708374 15.8333V19.5833H15.2917V15.8333C15.2917 12.9346 13.0148 10.5677 10.1519 10.4236C10.0602 10.419 9.96788 10.4167 9.87504 10.4167H6.12504C6.03221 10.4167 5.93992 10.419 5.84823 10.4236ZM6.18166 8.75001C6.73114 9.01695 7.3481 9.16668 8.00004 9.16668C8.65198 9.16668 9.26894 9.01695 9.81843 8.75001C11.2085 8.07471 12.1667 6.64926 12.1667 5.00001C12.1667 2.69882 10.3012 0.833344 8.00004 0.833344C5.69885 0.833344 3.83337 2.69882 3.83337 5.00001C3.83337 6.64926 4.79158 8.07471 6.18166 8.75001ZM13.625 17.9167V15.8333C13.625 13.7623 11.9461 12.0833 9.87504 12.0833H6.12504C4.05397 12.0833 2.37504 13.7623 2.37504 15.8333V17.9167H13.625ZM8.00004 7.50001C9.38075 7.50001 10.5 6.38072 10.5 5.00001C10.5 3.6193 9.38075 2.50001 8.00004 2.50001C6.61933 2.50001 5.50004 3.6193 5.50004 5.00001C5.50004 6.38072 6.61933 7.50001 8.00004 7.50001Z"
      fill="#4E5461"
      style="
        fill: #4e5461;
        fill: color(display-p3 0.304 0.3284 0.38);
        fill-opacity: 1;
      "
    />
    <defs>
      <filter
        id="filter0_b_10687_41"
        x="-5.95829"
        y="-5.83332"
        width="27.9167"
        height="32.0833"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feGaussianBlur in="BackgroundImageFix" stdDeviation="3.33333" />
        <feComposite
          in2="SourceAlpha"
          operator="in"
          result="effect1_backgroundBlur_10687_41"
        />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="effect1_backgroundBlur_10687_41"
          result="shape"
        />
      </filter>
    </defs>
  </svg>
</template>
