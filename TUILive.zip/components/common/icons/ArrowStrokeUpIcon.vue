<template>
  <svg
    width="15"
    height="20"
    viewBox="0 0 17 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M8.4707 4V14" stroke="currentColor" stroke-width="1.5" />
    <path
      d="M8.4707 3L3.4707 8"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="square"
    />
    <path
      d="M13.4707 8L8.4707 3"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="square"
    />
  </svg>
</template>
