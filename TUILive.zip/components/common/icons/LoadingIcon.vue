<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="36"
    height="36"
    viewBox="0 0 36 36"
    fill="none"
  >
    <path
      d="M18.0259 8.54816V2.76929"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M13.2957 9.80098L10.4062 4.79663"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M9.82704 13.252L4.82227 10.3625"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M8.54792 17.9744H2.76904"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M9.80122 22.7041L4.79688 25.5935"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M13.2517 26.1733L10.3623 31.1777"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M17.9741 27.4523V33.2307"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M22.7036 26.1987L25.5931 31.2031"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M26.1733 22.7483L31.1777 25.6377"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M27.4521 18.0256H33.2306"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M26.1992 13.2959L31.2036 10.4065"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
    <path
      d="M22.748 9.82716L25.6375 4.82239"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-miterlimit="10"
    />
  </svg>
</template>
