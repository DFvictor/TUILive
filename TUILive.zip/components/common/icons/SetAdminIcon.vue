<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Frame" clip-path="url(#clip0_6318_5279)">
      <g id="Group 7672">
        <g id="Group 7784">
          <path
            id="Vector"
            d="M8.90896 9.27299C10.7164 9.27299 12.1817 7.80774 12.1817 6.00027C12.1817 4.19279 10.7164 2.72754 8.90896 2.72754C7.10148 2.72754 5.63623 4.19279 5.63623 6.00027C5.63623 7.80774 7.10148 9.27299 8.90896 9.27299Z"
            stroke="currentColor"
            stroke-width="1.7"
            stroke-linecap="round"
          />
          <path
            id="Vector_2"
            d="M2 17.273C2 14.2048 4.24545 11.3412 6.14545 10.7275C6.14545 10.7275 7.87273 12.5684 8.90909 13.7957L11.6727 10.7275C13.2273 10.9321 15.8182 14.2048 15.8182 17.273"
            stroke="currentColor"
            stroke-width="1.7"
            stroke-linecap="round"
          />
        </g>
      </g>
      <path
        id="Vector_3"
        d="M18.5 18C18.5 13.3054 16.6066 10.3692 14.1082 9.18947C14.7565 8.63744 15.3914 7.47313 15.3914 5.83292C15.3914 4.5865 14.8012 3.33542 13.7695 2.5"
        stroke="currentColor"
        stroke-width="1.7"
        stroke-linejoin="round"
      />
    </g>
    <defs>
      <clipPath id="clip0_6318_5279">
        <rect width="20" height="20" fill="white" />
      </clipPath>
    </defs>
  </svg>
</template>
