<template>
  <svg
    width="25"
    height="25"
    viewBox="0 0 25 25"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M5.73859 13.7305V19.7305" stroke="#27C39F" stroke-width="3" />
    <path d="M12.0786 9.73047V19.7305" stroke="#27C39F" stroke-width="3" />
    <path d="M18.4086 4.73047V19.7305" stroke="#27C39F" stroke-width="3" />
  </svg>
</template>
