<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
  >
    <path
      d="M7.77713 8.22222C9.49535 8.22222 10.8882 6.82933 10.8882 5.11111C10.8882 3.39289 9.49535 2 7.77713 2C6.0589 2 4.66602 3.39289 4.66602 5.11111C4.66602 6.82933 6.0589 8.22222 7.77713 8.22222Z"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linejoin="round"
    />
    <path
      d="M18 14.8889L13.5556 14.8889"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M16.2222 16.6666L18 14.8889L16.2222 13.1111"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M11.3333 11.7778H7.68889C5.6976 11.7778 4.70196 11.7778 3.94138 12.1653C3.27235 12.5062 2.72841 13.0502 2.38753 13.7192C2 14.4798 2 15.4754 2 17.4667V18.0001H11.3333"
      stroke="currentColor"
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
  </svg>
</template>
