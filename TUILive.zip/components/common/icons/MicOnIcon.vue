<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
  >
    <rect x="11" y="20" width="2" height="4" fill="currentColor" />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M3.1499 11V12.5C3.1499 17.3877 7.11218 21.35 11.9999 21.35C16.8876 21.35 20.8499 17.3877 20.8499 12.5V11H19.1499V12.5C19.1499 16.4488 15.9487 19.65 11.9999 19.65C8.05107 19.65 4.8499 16.4488 4.8499 12.5V11H3.1499Z"
      fill="currentColor"
    />
    <rect
      x="7.85"
      y="1.85"
      width="8.3"
      height="14.8"
      rx="4.15"
      stroke="currentColor"
      stroke-width="1.7"
    />
  </svg>
</template>
