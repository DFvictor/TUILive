<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <!-- eslint-disable vue/no-parsing-error -->
    <g id="&#231;&#188;&#150;&#231;&#187;&#132; 5">
      <g id="&#231;&#188;&#150;&#231;&#187;&#132; 3">
        <path
          id="&#232;&#183;&#175;&#229;&#190;&#132;"
          d="M2 8C2 11.3137 4.68629 14 8 14C11.3137 14 14 11.3137 14 8C14 4.68629 11.3137 2 8 2C6.36788 2 4.88796 2.65167 3.80626 3.70902"
          stroke="white"
          stroke-width="1.5"
          stroke-linecap="square"
        />
        <path
          id="&#232;&#183;&#175;&#229;&#190;&#132;_2"
          d="M5.33317 4.66667H2.6665V2"
          stroke="white"
          stroke-width="1.5"
          stroke-linecap="square"
          stroke-linejoin="round"
        />
      </g>
    </g>
  </svg>
</template>
