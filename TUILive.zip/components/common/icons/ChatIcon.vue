<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M16.5001 9.84999H7.5001V8.14999H16.5001V9.84999Z"
      fill="currentColor"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M12.5002 13.85H7.50022V12.15H12.5002V13.85Z"
      style="fill: var(--active-color-2); fill-opacity: 1"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M8.70005 17.3V20.1L12.4333 17.3H20.3V4.7H3.7V17.3H8.70005ZM7.96005 22.78C7.56451 23.0766 7.00005 22.7944 7.00005 22.3V19H3C2.44772 19 2 18.5523 2 18V4C2 3.44772 2.44772 3 3 3H21C21.5523 3 22 3.44772 22 4V18C22 18.5523 21.5523 19 21 19H13L7.96005 22.78Z"
      fill="currentColor"
    />
  </svg>
</template>
