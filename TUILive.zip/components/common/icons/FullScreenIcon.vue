<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="25"
    viewBox="0 0 24 25"
    fill="none"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.2 4.72344V19.3234H19.8V4.72344H4.2ZM3.5 3.02344C2.94772 3.02344 2.5 3.47115 2.5 4.02344V20.0234C2.5 20.5757 2.94771 21.0234 3.5 21.0234H20.5C21.0523 21.0234 21.5 20.5757 21.5 20.0234V4.02344C21.5 3.47115 21.0523 3.02344 20.5 3.02344H3.5Z"
      fill="currentColor"
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M12.4984 8.37383H16.1484V12.0238H17.8484V7.52383V6.67383H16.9984H12.4984V8.37383ZM11.4984 15.6738H7.84844L7.84844 12.0238H6.14844V16.5238V17.3738H6.99844H11.4984V15.6738Z"
      style="fill: var(--active-color-2); fill-opacity: 1"
    />
  </svg>
</template>
