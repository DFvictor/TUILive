<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="&#231;&#148;&#187;&#231;&#172;&#148;">
      <g id="Union">
        <path
          fill-rule="evenodd"
          clip-rule="evenodd"
          d="M14.5791 4.48698L7.10505 17.4325L2.40326 18.4929L0.970703 13.8908L8.4448 0.945312L14.5791 4.48698ZM9.05484 3.22202L2.77894 14.0922L3.53735 16.5286L6.02653 15.9672L12.3024 5.09702L9.05484 3.22202Z"
          fill="currentColor"
        />
        <path
          d="M9.5978 17.5003L18.3329 17.5003V15.8337H10.5601L9.5978 17.5003Z"
          fill="currentColor"
        />
        <path
          d="M18.3331 13.7503L11.7633 13.7503L12.7256 12.0837H18.3331V13.7503Z"
          fill="currentColor"
        />
      </g>
    </g>
  </svg>
</template>
