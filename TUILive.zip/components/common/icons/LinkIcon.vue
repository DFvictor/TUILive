<template>
  <svg
    width="14"
    height="13"
    viewBox="0 0 14 13"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 1792">
      <g id="Group 7870">
        <path
          id="Vector 88"
          d="M5.35 1H2C1.72386 1 1.5 1.22386 1.5 1.5V11.5C1.5 11.7761 1.72386 12 2 12H12C12.2761 12 12.5 11.7761 12.5 11.5V8.15"
          stroke="currentColor"
          stroke-width="1.5"
        />
        <path
          id="Vector 87"
          d="M7.5 1H12.5M12.5 1V6M12.5 1L7.5 6"
          stroke="currentColor"
          stroke-width="1.5"
        />
      </g>
    </g>
  </svg>
</template>
