<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M10 3.33301H2.5V16.6663H10V3.33301Z"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-linejoin="round"
    />
    <path
      d="M17.5 3.33301H12.5V6.66634H17.5V3.33301Z"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-linejoin="round"
    />
    <path
      d="M17.5 9.16699H12.5V16.667H17.5V9.16699Z"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-linejoin="round"
    />
  </svg>
</template>
