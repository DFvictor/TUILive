<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <!-- eslint-disable vue/no-parsing-error -->
    <g id="&#231;&#188;&#150;&#231;&#187;&#132; 16">
      <g id="Group 48097543" filter="url(#filter0_d_9286_1548)">
        <g id="Group 48097543_2">
          <path
            id="Vector"
            d="M9.6875 3.125V16.875"
            stroke="white"
            stroke-width="1.25"
          />
          <path
            id="Rectangle 2379"
            d="M9.6875 5.3125H4.0625V14.6875H9.6875V5.3125Z"
            stroke="white"
            stroke-width="1.25"
          />
          <path
            id="Rectangle 2380"
            d="M11.5625 5.3125H15.9375V14.6875H11.5625"
            stroke="white"
            stroke-width="1.25"
          />
        </g>
      </g>
    </g>
    <defs>
      <filter
        id="filter0_d_9286_1548"
        x="0.9375"
        y="0.625"
        width="18.125"
        height="18.75"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feColorMatrix
          in="SourceAlpha"
          type="matrix"
          values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0"
          result="hardAlpha"
        />
        <feOffset />
        <feGaussianBlur stdDeviation="1.25" />
        <feComposite in2="hardAlpha" operator="out" />
        <feColorMatrix
          type="matrix"
          values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.25 0"
        />
        <feBlend
          mode="normal"
          in2="BackgroundImageFix"
          result="effect1_dropShadow_9286_1548"
        />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="effect1_dropShadow_9286_1548"
          result="shape"
        />
      </filter>
    </defs>
  </svg>
</template>
