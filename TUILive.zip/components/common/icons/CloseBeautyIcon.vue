<template>
  <svg
    width="32"
    height="32"
    viewBox="0 0 32 32"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <!-- eslint-disable vue/no-parsing-error -->
    <g id="&#229;&#133;&#179;&#233;&#151;&#173;">
      <g id="Group 48097253">
        <circle
          id="Ellipse 347"
          cx="16"
          cy="16"
          r="12.8667"
          stroke="#4F586B"
          stroke-width="2"
        />
        <path
          id="Vector 186"
          d="M25.6001 6.40002L6.40015 25.6"
          stroke="#4F586B"
          stroke-width="2"
        />
      </g>
    </g>
  </svg>
</template>
