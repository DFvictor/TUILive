<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M13.667 3L7.54178 10L13.667 17H11.0094L5.46042 10.6585L4.8842 10L5.46042 9.34148L11.0094 3H13.667Z"
      fill="currentColor"
    />
  </svg>
</template>
