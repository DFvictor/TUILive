<template>
  <svg
    width="28"
    height="7"
    viewBox="0 0 28 7"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M2 2L11.0896 4.27239C13.0005 4.75011 14.9995 4.75011 16.9104 4.27239L26 2"
      stroke="currentColor"
      stroke-width="3"
      stroke-linecap="round"
    />
  </svg>
</template>
