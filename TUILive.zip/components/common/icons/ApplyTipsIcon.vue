<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Frame">
      <path
        id="Vector"
        d="M17 10H7C6.44772 10 6 10.4477 6 11V18C6 18.5523 6.44772 19 7 19H17C17.5523 19 18 18.5523 18 18V11C18 10.4477 17.5523 10 17 10Z"
        fill="currentColor"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <path
        id="Vector_2"
        d="M9 10V7C9 5.15905 10.3431 4 12 4C12.9246 4 13.7516 4.36098 14.3019 5C14.5444 5.2817 14.7333 5.6174 14.853 6"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <path
        id="Vector_3"
        d="M14.4004 14.3999H9.60039"
        stroke="white"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <path
        id="Vector_4"
        d="M3 9V15"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <path
        id="Vector_5"
        d="M21 9V15"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
    </g>
  </svg>
</template>
