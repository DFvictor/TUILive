<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M6.95377 20H16C16.5523 20 17 19.5523 17 19V16.293L21.3779 18.336C22.0409 18.6454 22.8008 18.1614 22.8008 17.4298V6.5702C22.8008 5.83858 22.0409 5.35462 21.3779 5.66401L17.258 7.58664L15.3 9.9454V18.3H8.36493L6.95377 20ZM13.9504 5.7H2.7V18.3H3.4913L2.08014 20H2C1.44772 20 1 19.5523 1 19V5C1 4.44772 1.44772 4 2 4H15.3616L13.9504 5.7ZM17.0008 9.58267L21.1008 7.66933V16.3307L17.0008 14.4173V9.58267Z"
      fill="currentColor"
    />
    <path
      d="M4.14339 20.6077L17.5022 4.47709"
      stroke="#ED414D"
      style="
        stroke: #ed414d;
        stroke: color(display-p3 0.9292 0.2555 0.3004);
        stroke-opacity: 1;
      "
      stroke-width="1.5"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M5 9H8.5"
      style="stroke: var(--active-color-2); stroke-opacity: 1"
      stroke-width="1.7"
    />
  </svg>
</template>
