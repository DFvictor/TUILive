<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <mask id="path-1-inside-1_3678_51136" fill="white">
      <rect x="2" y="2" width="9" height="9" rx="1" />
    </mask>
    <rect
      x="2"
      y="2"
      width="9"
      height="9"
      rx="1"
      stroke="currentColor"
      stroke-width="3.4"
      mask="url(#path-1-inside-1_3678_51136)"
    />
    <rect
      x="13.35"
      y="2.35"
      width="8.3"
      height="8.3"
      rx="4.15"
      style="stroke: var(--active-color-2); stroke-opacity: 1"
      stroke-width="1.7"
    />
    <rect
      x="13.35"
      y="2.35"
      width="8.3"
      height="8.3"
      rx="4.15"
      stroke="currentColor"
      stroke-width="1.7"
    />
    <rect
      x="15.75"
      y="4.75"
      width="3.5"
      height="3.5"
      rx="1.75"
      style="fill: var(--active-color-2); fill-opacity: 1"
    />
    <rect
      x="2.35"
      y="13.35"
      width="8.3"
      height="8.3"
      rx="4.15"
      stroke="currentColor"
      stroke-width="1.7"
    />
    <mask id="path-6-inside-2_3678_51136" fill="white">
      <rect x="13" y="13" width="9" height="9" rx="1" />
    </mask>
    <rect
      x="13"
      y="13"
      width="9"
      height="9"
      rx="1"
      stroke="currentColor"
      stroke-width="3.4"
      mask="url(#path-6-inside-2_3678_51136)"
    />
  </svg>
</template>
