<template>
  <svg
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <mask id="path-1-inside-1_9286_2150" fill="white">
      <path
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12 10C14.2091 10 16 8.20914 16 6C16 3.79086 14.2091 2 12 2C9.79086 2 8 3.79086 8 6C8 8.20914 9.79086 10 12 10ZM10 12C6.68629 12 4 14.6863 4 18V21H20V18C20 14.6863 17.3137 12 14 12H10Z"
      />
    </mask>
    <path
      d="M4 21H2.3V22.7H4V21ZM20 21V22.7H21.7V21H20ZM14.3 6C14.3 7.27025 13.2703 8.3 12 8.3V11.7C15.148 11.7 17.7 9.14802 17.7 6H14.3ZM12 3.7C13.2703 3.7 14.3 4.72975 14.3 6H17.7C17.7 2.85198 15.148 0.3 12 0.3V3.7ZM9.7 6C9.7 4.72975 10.7297 3.7 12 3.7V0.3C8.85198 0.3 6.3 2.85198 6.3 6H9.7ZM12 8.3C10.7297 8.3 9.7 7.27025 9.7 6H6.3C6.3 9.14802 8.85198 11.7 12 11.7V8.3ZM5.7 18C5.7 15.6252 7.62518 13.7 10 13.7V10.3C5.74741 10.3 2.3 13.7474 2.3 18H5.7ZM5.7 21V18H2.3V21H5.7ZM20 19.3H4V22.7H20V19.3ZM18.3 18V21H21.7V18H18.3ZM14 13.7C16.3748 13.7 18.3 15.6252 18.3 18H21.7C21.7 13.7474 18.2526 10.3 14 10.3V13.7ZM10 13.7H14V10.3H10V13.7Z"
      fill="currentColor"
      mask="url(#path-1-inside-1_9286_2150)"
    />
    <path d="M3 12L7 8" stroke="var(--active-color-2)" stroke-width="1.7" />
    <path d="M18 12L22 8" stroke="var(--active-color-2)" stroke-width="1.7" />
    <path
      d="M2.00098 7L6.00098 3"
      stroke="var(--active-color-2)"
      stroke-width="1.7"
    />
    <path
      d="M17.001 7L21.001 3"
      stroke="var(--active-color-2)"
      stroke-width="1.7"
    />
  </svg>
</template>
