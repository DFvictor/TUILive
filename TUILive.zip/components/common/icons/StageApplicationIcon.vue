<template>
  <svg
    width="25"
    height="24"
    viewBox="0 0 25 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="&#229;&#136;&#151;&#232;&#161;&#168;-list 1">
      <path
        id="Vector"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M2.42383 6.00391H4.42774V4H2.42383V6.00391Z"
        fill="currentColor"
      />
      <path
        id="Vector_2"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M2.42383 13.0039H4.42774V11H2.42383V13.0039Z"
        fill="currentColor"
      />
      <path
        id="Vector_3"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M2.42383 20.0039H4.42774V18H2.42383V20.0039Z"
        fill="currentColor"
      />
      <path
        id="Vector_4"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.42383 4H22.4238V6H7.42383V4Z"
        fill="currentColor"
      />
      <path
        id="Vector_5"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.42383 11H22.4238V13H7.42383V11Z"
        fill="currentColor"
      />
      <path
        id="Vector_6"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M7.42383 18H22.4238V20H7.42383V18Z"
        fill="currentColor"
      />
    </g>
  </svg>
</template>
