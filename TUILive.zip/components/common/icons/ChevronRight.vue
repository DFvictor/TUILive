<template>
  <svg
    width="6"
    height="10"
    viewBox="0 0 6 10"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M1.4603 9.45947L0.541064 8.54023L4.08144 4.99985L0.541064 1.45947L1.4603 0.540234L5.91992 4.99985L1.4603 9.45947Z"
      fill="currentColor"
    />
  </svg>
</template>
