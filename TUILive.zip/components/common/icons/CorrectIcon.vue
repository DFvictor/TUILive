<template>
  <svg
    width="17"
    height="12"
    viewBox="0 0 17 12"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M6.84647 8.6421L15.4026 0.0859375L16.6666 1.34989L6.84647 11.17L0.714844 5.03838L1.9788 3.77443L6.84647 8.6421Z"
      fill="#006EFF"
    />
  </svg>
</template>
