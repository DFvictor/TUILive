<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="copy">
      <path
        id="Union"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M3.5 3.5V9.5V11H2V3C2 2.44772 2.44772 2 3 2H11V3.5H9.5H3.5ZM5 6C5 5.44772 5.44772 5 6 5H13C13.5523 5 14 5.44772 14 6V13C14 13.5523 13.5523 14 13 14H6C5.44772 14 5 13.5523 5 13V6ZM6.5 12.5V6.5H12.5V12.5H6.5Z"
        fill="currentColor"
      />
    </g>
  </svg>
</template>
