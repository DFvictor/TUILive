<template>
  <svg
    width="25"
    height="24"
    viewBox="0 0 25 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      opacity="0.5"
      d="M5.73859 13.5V19.5"
      stroke="#8F9AB2"
      stroke-width="3"
    />
    <path
      opacity="0.5"
      d="M12.0786 9.5V19.5"
      stroke="#8F9AB2"
      stroke-width="3"
    />
    <path opacity="0.5" d="M18.4086 4.5V13" stroke="#8F9AB2" stroke-width="3" />
    <path d="M20.1586 14L14.1586 20" stroke="#ED414D" stroke-width="1.5" />
    <path d="M20.1586 20L14.1586 14" stroke="#ED414D" stroke-width="1.5" />
  </svg>
</template>
