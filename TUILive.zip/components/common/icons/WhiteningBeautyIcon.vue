<template>
  <svg
    width="30"
    height="30"
    viewBox="0 0 30 30"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 48097287">
      <path
        id="Ellipse 349"
        d="M27 15C27 21.6274 21.6274 27 15 27C8.37258 27 3 21.6274 3 15C3 12.1605 3.98496 9.55384 5.63267 7.49904C6.3356 6.62243 7.159 5.84657 8.07758 5.19665C10.0333 3.81292 12.4202 3 15 3C21.6274 3 27 8.37258 27 15Z"
        stroke="#4F586B"
        stroke-width="2"
      />
      <circle id="Ellipse 350" cx="10.5" cy="12.5" r="1.5" fill="#4F586B" />
      <circle id="Ellipse 351" cx="19.5" cy="12.5" r="1.5" fill="#4F586B" />
      <path
        id="Ellipse 352"
        d="M18 17C18 18.6569 16.6569 20 15 20C13.3431 20 12 18.6569 12 17"
        stroke="#4F586B"
        stroke-width="2"
      />
      <path
        id="Vector 188"
        d="M8 5L11 8M22 5L19 8"
        stroke="#4F586B"
        stroke-width="2"
      />
      <path
        id="Vector 189"
        d="M8 25L11 22M22 25L19 22"
        stroke="#4F586B"
        stroke-width="2"
      />
    </g>
  </svg>
</template>
