<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 8007">
      <circle
        id="Ellipse 269"
        cx="10"
        cy="10"
        r="7.65"
        stroke="currentColor"
        stroke-width="1.7"
      />
      <path
        id="Intersect"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M12.4744 11.1743C12.0041 12.0597 11.0725 12.6626 10.0001 12.6626C8.92766 12.6626 7.99607 12.0597 7.52573 11.1744L6.02344 11.9708C6.77934 13.3937 8.27654 14.3626 10.0001 14.3626C11.7236 14.3626 13.2208 13.3936 13.9767 11.9707L12.4744 11.1743Z"
        fill="currentColor"
      />
      <circle id="Ellipse 273" cx="7.1" cy="8.1" r="1.1" fill="currentColor" />
      <circle
        id="Ellipse 274"
        cx="12.8998"
        cy="8.1"
        r="1.1"
        fill="currentColor"
      />
    </g>
  </svg>
</template>
