<template>
<svg width="10" height="10" viewBox="0 0 10 7" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M1.02265 3.32438L2.63074 1.18704C2.73771 1.04487 2.90528 0.961243 3.08319 0.961243H4.99585H6.90706C7.08448 0.961243 7.25164 1.04441 7.35866 1.18591L8.97576 3.32414C9.13363 3.53289 9.11595 3.82551 8.9341 4.01373L5.38206 7.69015C5.17321 7.90631 4.82679 7.90631 4.61794 7.69015L1.06511 4.0129C0.883605 3.82504 0.865603 3.53311 1.02265 3.32438Z" fill="white"/>
<path d="M1.44576 3.39958L2.81252 1.59617C2.91916 1.45546 3.08552 1.3728 3.26207 1.3728H4.99226H6.71869C6.89428 1.3728 7.05986 1.45457 7.16659 1.594L8.47517 3.30341C8.64545 3.52585 8.62669 3.83955 8.43111 4.0401L5.29918 7.2518C5.13226 7.42297 4.85707 7.42283 4.69033 7.2515L1.4799 3.9527C1.33335 3.80212 1.31884 3.56704 1.44576 3.39958Z" fill="#2B6AD6" fill-opacity="0.1"/>
<g opacity="0.5">
<mask id="mask0_9264_5095" style="mask-type:alpha" maskUnits="userSpaceOnUse" x="1" y="1" width="8" height="6">
<path d="M1.86193 3.39983L3.0668 1.92872C3.16772 1.80551 3.31858 1.73407 3.47784 1.73407H6.49519C6.65665 1.73407 6.80936 1.80749 6.91018 1.93361L8.12281 3.45044C8.25788 3.61939 8.24244 3.86332 8.08715 4.0139L5.28485 6.73115C5.12112 6.88991 4.86057 6.88889 4.69809 6.72884L1.8921 3.96484C1.73754 3.81259 1.72447 3.56766 1.86193 3.39983Z" fill="#DEA6B3" stroke="url(#paint0_linear_9264_5095)" stroke-width="0.010494"/>
</mask>
<g mask="url(#mask0_9264_5095)">
<path d="M1.92236 3.31776L3.06274 1.9254C3.16465 1.80097 3.31701 1.72882 3.47784 1.72882H6.49519C6.65825 1.72882 6.81246 1.80297 6.91428 1.93033L8.06361 3.36799C8.23626 3.58395 8.21653 3.89576 8.01803 4.08823L5.28851 6.73491C5.12272 6.89567 4.85892 6.89463 4.6944 6.73258L1.96092 4.04C1.76336 3.84539 1.74664 3.5323 1.92236 3.31776Z" fill="url(#paint1_radial_9264_5095)"/>
<rect opacity="0.5" x="0.986206" y="4.02606" width="0.596132" height="7.73672" transform="rotate(-90 0.986206 4.02606)" fill="#E5E7FF"/>
<path opacity="0.3" d="M8.42224 18.4246L3.49857 1.50464L2.80269 1.50464L8.06496 18.6031L8.42224 18.4246Z" fill="url(#paint2_linear_9264_5095)"/>
<path opacity="0.3" d="M1.62184 18.4247L6.48097 1.54492L7.17685 1.54492L1.97912 18.6032L1.62184 18.4247Z" fill="url(#paint3_linear_9264_5095)"/>
<rect x="1.69226" y="4.89514" width="6.63" height="4.23469" fill="url(#paint4_linear_9264_5095)"/>
</g>
</g>
<defs>
<linearGradient id="paint0_linear_9264_5095" x1="3.56411" y1="2.10068" x2="6.99134" y2="8.37543" gradientUnits="userSpaceOnUse">
<stop stop-color="#FAAEAC"/>
<stop offset="1" stop-color="#E86666"/>
</linearGradient>
<radialGradient id="paint1_radial_9264_5095" cx="0" cy="0" r="1" gradientUnits="userSpaceOnUse" gradientTransform="translate(5.13247 3.84308) rotate(90) scale(5.4005 4.7104)">
<stop stop-color="white"/>
<stop offset="1" stop-color="#2B6AD6"/>
</radialGradient>
<linearGradient id="paint2_linear_9264_5095" x1="3.09542" y1="3.81827" x2="5.11446" y2="7.85973" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="white" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint3_linear_9264_5095" x1="6.94866" y1="3.81835" x2="4.92961" y2="7.85981" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="white" stop-opacity="0"/>
</linearGradient>
<linearGradient id="paint4_linear_9264_5095" x1="5.00726" y1="6.73142" x2="4.98791" y2="8.86746" gradientUnits="userSpaceOnUse">
<stop stop-color="#2B6AD6" stop-opacity="0"/>
<stop offset="1" stop-color="#2B6AD6"/>
</linearGradient>
</defs>
</svg>
</template>