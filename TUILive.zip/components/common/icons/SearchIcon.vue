<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
  >
    <g opacity="0.8">
      <path
        d="M8.74935 15.8337C12.6613 15.8337 15.8327 12.6623 15.8327 8.75033C15.8327 4.83833 12.6613 1.66699 8.74935 1.66699C4.83735 1.66699 1.66602 4.83833 1.66602 8.75033C1.66602 12.6623 4.83735 15.8337 8.74935 15.8337Z"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linejoin="round"
      />
      <path
        d="M13.8418 13.8428L17.3773 17.3783"
        stroke="currentColor"
        stroke-width="1.5"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    </g>
  </svg>
</template>
