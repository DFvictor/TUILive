<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
  >
    <g clip-path="url(#clip0_3426_9495)">
      <path
        d="M10.0012 9.27299C11.8087 9.27299 13.274 7.80774 13.274 6.00027C13.274 4.19279 11.8087 2.72754 10.0012 2.72754C8.19377 2.72754 6.72852 4.19279 6.72852 6.00027C6.72852 7.80774 8.19377 9.27299 10.0012 9.27299Z"
        stroke="#6B758A"
        style="
          stroke: #6b758a;
          stroke: color(display-p3 0.4196 0.4588 0.5412);
          stroke-opacity: 1;
        "
        stroke-width="1.7"
        stroke-linecap="round"
      />
      <path
        d="M3.0918 17.273C3.0918 14.2048 5.33725 11.3412 7.23725 10.7275C7.23725 10.7275 8.96452 12.5684 10.0009 13.7957L12.7645 10.7275C14.3191 10.9321 16.91 14.2048 16.91 17.273"
        stroke="#6B758A"
        style="
          stroke: #6b758a;
          stroke: color(display-p3 0.4196 0.4588 0.5412);
          stroke-opacity: 1;
        "
        stroke-width="1.7"
        stroke-linecap="round"
      />
    </g>
    <defs>
      <clipPath id="clip0_3426_9495">
        <rect
          width="20"
          height="20"
          fill="white"
          style="fill: white; fill-opacity: 1"
        />
      </clipPath>
    </defs>
  </svg>
</template>
