<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Frame">
      <path
        id="Vector"
        d="M14.6668 8V3H8.00016H1.3335V8V13H8.00016"
        stroke="currentColor"
        stroke-width="1.2"
        stroke-linejoin="round"
      />
      <path
        id="Vector_2"
        d="M14.6667 11.333H10"
        stroke="#4F586B"
        stroke-width="1.2"
        stroke-linejoin="round"
      />
      <path
        id="Vector_3"
        d="M13 9.66699L14.6667 11.3337L13 13.0003"
        stroke="currentColor"
        stroke-width="1.2"
        stroke-linejoin="round"
      />
      <path
        id="Vector_4"
        d="M1.3335 3L8.00016 8L14.6668 3"
        stroke="currentColor"
        stroke-width="1.2"
        stroke-linejoin="round"
      />
    </g>
  </svg>
</template>
