<template>
  <svg
    width="16"
    height="16"
    viewBox="0 0 16 16"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Group 7827">
      <path
        id="Union"
        fill-rule="evenodd"
        clip-rule="evenodd"
        d="M9.58977 7.99967L14.4516 3.13787L12.8606 1.54687L7.99878 6.40868L3.13796 1.54785L1.54697 3.13884L6.40779 7.99967L1.54688 12.8606L3.13787 14.4516L7.99878 9.59066L12.8607 14.4525L14.4517 12.8616L9.58977 7.99967Z"
        fill="currentColor"
      />
    </g>
  </svg>
</template>
