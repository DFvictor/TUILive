<template>
  <svg
    width="25"
    height="24"
    viewBox="0 0 25 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path d="M5.73859 13.5V19.5" stroke="#F39843" stroke-width="3" />
    <path d="M12.0786 9.5V19.5" stroke="#F39843" stroke-width="3" />
    <path
      opacity="0.5"
      d="M18.4086 4.5V19.5"
      stroke="#8F9AB2"
      stroke-width="3"
    />
  </svg>
</template>
