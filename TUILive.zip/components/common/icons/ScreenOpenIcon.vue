<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
  >
    <path
      d="M4.99935 14.1674H3.16601C2.33759 14.1674 1.66602 13.4958 1.66602 12.6674V4.41699C1.66602 3.58856 2.33759 2.91699 3.16601 2.91699H16.8327C17.6611 2.91699 18.3327 3.58856 18.3327 4.41699V12.6674C18.3327 13.4958 17.6611 14.1674 16.8327 14.1674H14.9993"
      stroke="#B2BBD1"
      style="
        stroke: #b2bbd1;
        stroke: color(display-p3 0.697 0.7318 0.82);
        stroke-opacity: 1;
      "
      stroke-width="1.7"
      stroke-linecap="square"
      stroke-linejoin="round"
    />
    <path
      d="M9.9987 13L5.83203 17.1667H14.1654L9.9987 13Z"
      stroke="#B2BBD1"
      style="
        stroke: #b2bbd1;
        stroke: color(display-p3 0.697 0.7318 0.82);
        stroke-opacity: 1;
      "
      stroke-width="1.7"
      stroke-linejoin="round"
    />
  </svg>
</template>
