<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    class="design-iconfont"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M1.66669 14.9998C1.66669 12.3681 3.69998 10.2112 6.28134 10.0145C6.40852 10.0048 6.53703 9.99985 6.66669 9.99985H10C10.1297 9.99985 10.2582 10.0048 10.3854 10.0145C12.9667 10.2112 15 12.3681 15 14.9998V18.3332H1.66669V14.9998ZM13.3334 14.9998V16.6665H3.33335V14.9998C3.33335 13.1589 4.82574 11.6665 6.66669 11.6665H10C11.841 11.6665 13.3334 13.1589 13.3334 14.9998Z"
      fill="#4E5461"
      style="
        fill: #4e5461;
        fill: color(display-p3 0.304 0.3284 0.38);
        fill-opacity: 1;
      "
    />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M6.66669 8.3602C6.64897 8.3514 6.63135 8.34246 6.61379 8.33339C5.40776 7.70998 4.58335 6.45126 4.58335 5C4.58335 2.92893 6.26229 1.25 8.33335 1.25C10.4044 1.25 12.0834 2.92893 12.0834 5C12.0834 6.45126 11.259 7.70998 10.0529 8.33339C10.0354 8.34246 10.0177 8.3514 10 8.3602C9.49795 8.60971 8.93204 8.75 8.33335 8.75C7.73467 8.75 7.16875 8.60971 6.66669 8.3602ZM10.4167 5C10.4167 6.15059 9.48395 7.08333 8.33335 7.08333C7.18276 7.08333 6.25002 6.15059 6.25002 5C6.25002 3.84941 7.18276 2.91667 8.33335 2.91667C9.48395 2.91667 10.4167 3.84941 10.4167 5Z"
      fill="#4E5461"
      style="
        fill: #4e5461;
        fill: color(display-p3 0.304 0.3284 0.38);
        fill-opacity: 1;
      "
    />
    <path
      d="M12.5651 8.67685L13.2006 7.38123C13.5522 6.66449 13.7504 5.85772 13.7504 4.99992C13.7504 4.13294 13.5467 3.31354 13.1846 2.58695L14.6269 1.74561C15.1318 2.72004 15.417 3.82667 15.417 4.99992C15.417 6.11771 15.1581 7.17503 14.697 8.11518C16.8927 9.61592 18.3337 12.1396 18.3337 14.9999V18.3333L16.667 18.3333V14.9999C16.667 12.7132 15.5172 10.6946 13.7565 9.49115L12.5651 8.67685Z"
      fill="#4E5461"
      style="
        fill: #4e5461;
        fill: color(display-p3 0.304 0.3284 0.38);
        fill-opacity: 1;
      "
    />
    <defs>
      <filter
        id="filter0_b_10685_2618"
        x="-4.99998"
        y="-5.41667"
        width="30.0003"
        height="30.4166"
        filterUnits="userSpaceOnUse"
        color-interpolation-filters="sRGB"
      >
        <feFlood flood-opacity="0" result="BackgroundImageFix" />
        <feGaussianBlur in="BackgroundImageFix" stdDeviation="3.33333" />
        <feComposite
          in2="SourceAlpha"
          operator="in"
          result="effect1_backgroundBlur_10685_2618"
        />
        <feBlend
          mode="normal"
          in="SourceGraphic"
          in2="effect1_backgroundBlur_10685_2618"
          result="shape"
        />
      </filter>
    </defs>
  </svg>
</template>
