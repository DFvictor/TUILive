<template>
  <svg
    width="20"
    height="20"
    viewBox="0 0 20 20"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="Frame" clip-path="url(#clip0_6318_5268)">
      <g id="Group 7672">
        <g id="Group 7784">
          <path
            id="Vector"
            d="M10 9.27299C11.8075 9.27299 13.2727 7.80774 13.2727 6.00027C13.2727 4.19279 11.8075 2.72754 10 2.72754C8.19254 2.72754 6.72729 4.19279 6.72729 6.00027C6.72729 7.80774 8.19254 9.27299 10 9.27299Z"
            stroke="currentColor"
            stroke-width="1.7"
            stroke-linecap="round"
          />
          <path
            id="Vector_2"
            d="M3.09106 17.273C3.09106 14.2048 5.33652 11.3412 7.23652 10.7275C7.23652 10.7275 8.96379 12.5684 10.0002 13.7957L12.7638 10.7275C14.3183 10.9321 16.9092 14.2048 16.9092 17.273"
            stroke="currentColor"
            stroke-width="1.7"
            stroke-linecap="round"
          />
        </g>
      </g>
    </g>
    <defs>
      <clipPath id="clip0_6318_5268">
        <rect width="20" height="20" fill="white" />
      </clipPath>
    </defs>
  </svg>
</template>
