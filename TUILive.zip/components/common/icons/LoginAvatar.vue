<template>
  <svg
    width="28"
    height="28"
    viewBox="0 0 28 28"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle cx="14" cy="14" r="14" fill="#8F9AB2" />
    <circle cx="14" cy="11" r="6" fill="#D5E0F2" />
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M4.23242 24.0289C6.40892 20.9844 9.97323 19 14.001 19C18.0287 19 21.593 20.9843 23.7695 24.0287C21.247 26.4861 17.8007 28 14.0008 28C10.2011 28 6.75489 26.4862 4.23242 24.0289Z"
      fill="#D5E0F2"
    />
  </svg>
</template>
