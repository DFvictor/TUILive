<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
  >
    <path
      fill-rule="evenodd"
      clip-rule="evenodd"
      d="M7.70011 3.7V7.5H6.00011V3C6.00011 2.44772 6.44782 2 7.00011 2H20.5001C21.0524 2 21.5001 2.44772 21.5001 3V21C21.5001 21.5523 21.0524 22 20.5001 22H7.00011C6.44782 22 6.00011 21.5523 6.00011 21V16.5H7.70011V20.3H19.8001V3.7H7.70011ZM12.7022 7.99995L16.1021 11.3998L16.7033 12.001L16.102 12.602L12.7027 16H10.298L14.2989 12.0007L10.298 7.99995H12.7022ZM2 12.85H11V11.15H2V12.85Z"
      fill="white"
      style="fill: white; fill-opacity: 1"
    />
  </svg>
</template>
