<template>
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="44"
    height="44"
    viewBox="0 0 44 44"
    fill="none"
  >
    <path
      d="M11.0013 32.0966H8.2513H3.66797V7.3457H40.3346V32.0966H33.0013"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <path
      d="M22 29L14 37H30L22 29Z"
      stroke="currentColor"
      stroke-width="1.7"
      stroke-linecap="round"
      stroke-linejoin="round"
    />
    <circle cx="16.043" cy="19.709" r="1.375" fill="currentColor" />
    <circle cx="22" cy="19.709" r="1.375" fill="currentColor" />
    <circle cx="27.957" cy="19.709" r="1.375" fill="currentColor" />
  </svg>
</template>
