<template>
  <div class="content-container">
    <stream-container />
  </div>
</template>

<script setup lang="ts">
import StreamContainer from './StreamContainer/StreamContainer.vue';
</script>

<style lang="scss" scoped>
.content-container {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
}
</style>
