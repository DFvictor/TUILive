import { ref } from "vue";
import TUIRoomEngine, {
  TUIAutoPlayCallbackInfo,
  TUIRoomEvents,
} from "@tencentcloud/tuiroom-engine-js";
import useGetRoomEngine from "../../../hooks/useRoomEngine";
import { useI18n } from "../../../locales";

const { t } = useI18n();
const roomEngine = useGetRoomEngine();
const isShowAutoPlayFailPrompt = ref(false);
const autoPlayFailPromptText = ref("");
const resumeFunction = ref<(() => void) | null>(null);

const autoplayFailCallback = (callbackInfo: TUIAutoPlayCallbackInfo) => {
  const { resume } = callbackInfo;
  if (!isShowAutoPlayFailPrompt.value) {
    isShowAutoPlayFailPrompt.value = true;
    autoPlayFailPromptText.value = t("Click page to resume audio/video play");
    resumeFunction.value = resume;
  }
};

const closeAutoPlayFailPrompt = () => {
  if (isShowAutoPlayFailPrompt.value) {
    if (resumeFunction.value && typeof resumeFunction.value === "function") {
      resumeFunction.value();
      resumeFunction.value = null;
    }
    isShowAutoPlayFailPrompt.value = false;
    autoPlayFailPromptText.value = "";
    cleanupAutoPlayListener();
  }
};

const cleanupAutoPlayListener = () => {
  roomEngine.instance?.off(
    TUIRoomEvents.onAutoPlayFailed, 
    autoplayFailCallback
  );
};

export default function useAutoPlayFailPrompt() {
  TUIRoomEngine.once("ready", () => {
    roomEngine.instance?.on(
      TUIRoomEvents.onAutoPlayFailed,
      autoplayFailCallback
    );
  });

  return {
    isShowAutoPlayFailPrompt,
    autoPlayFailPromptText,
    closeAutoPlayFailPrompt,
  };
}
