<template>
  <div class="hint-dialog-container">
    <span class="describe">{{ props.text }}</span>
  </div>
</template>

<script lang="ts" setup>
import { defineProps, defineEmits, onMounted, onUnmounted } from 'vue';

interface Props {
  text: string;
}

const props = defineProps<Props>();
const emit = defineEmits(['close']);

const emitCloseEvent = () => {
  emit('close');
};

onMounted(() => {
  document.addEventListener('click', emitCloseEvent, true)
})

onUnmounted(() => [
  document.removeEventListener('click', emitCloseEvent, true)
])
</script>

<style lang="scss" scoped>
@import "../../../assets/style/variables.scss";

.hint-dialog-container {
  display: flex;
  justify-content: center;
  align-items: center;
  position: absolute;
  left: 0;
  top: 0;
  width: 100%;
  height: 100%;
  color: #F3AEB9;
  z-index: $levelFourZIndex;

  .describe {
    transform: translateY(1.5rem);
  }
}
</style>