import StreamRegion from './StreamRegionPC.vue';

export default StreamRegion;
