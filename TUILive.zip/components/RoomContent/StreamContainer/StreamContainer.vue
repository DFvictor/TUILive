<template>
  <div id="streamContainer" class="tui-stream-container">
    <StreamRegion
      v-if="enlargeStream"
      :streamInfo="enlargeStream"
      :isEnlarge="true"
      :observerViewInVisible="true"
      :isNeedPlayStream="true"
    />
    <div v-else class="avatar-region">
      <Avatar class="avatar" />
    </div>
    <AutoPlayFailPrompt 
      v-if="isShowAutoPlayFailPrompt"
      :text="autoPlayFailPromptText"
      @close="closeAutoPlayFailPrompt"
    />
  </div>
  <!-- </div> -->
</template>

<script setup lang="ts">
import { ref, onUnmounted, Ref, watch } from 'vue';
import { storeToRefs } from 'pinia';
import TUIRoomEngine, {
  TUIUserInfo,
  TUIChangeReason,
  TUIRoomEvents,
  TUIVideoStreamType,
  TUISeatInfo,
} from '@tencentcloud/tuiroom-engine-js';
import { StreamInfo, useRoomStore } from '../../../stores/room';
import { useBasicStore } from '../../../stores/basic';
import { LAYOUT } from '../../../constants/render';
import StreamRegion from '../StreamRegion';
import logger from '../../../utils/common/logger';
import Avatar from '../../common/Avatar.vue';
import AutoPlayFailPrompt from '../AutoPlayFailPrompt/index.vue';
import useGetRoomEngine from '../../../hooks/useRoomEngine';
import useAutoPlayFailPrompt from '../AutoPlayFailPrompt/useAutoPlayFailPrompt';

const logPrefix = '[StreamContainer]';
const roomEngine = useGetRoomEngine();
const { isShowAutoPlayFailPrompt, autoPlayFailPromptText, closeAutoPlayFailPrompt } = useAutoPlayFailPrompt();

const roomStore = useRoomStore();
const { streamList } = storeToRefs(roomStore);
const basicStore = useBasicStore();
const { layout } = storeToRefs(basicStore);
const enlargeStream: Ref<StreamInfo | null> = ref(streamList.value[0]);

watch(
  () => streamList.value.length,
  val => {
    if (val === 1) {
      enlargeStream.value = streamList.value[0];
      return;
    }
  }
);

const onUserVideoStateChanged = (eventInfo: {
  userId: string;
  streamType: TUIVideoStreamType;
  hasVideo: boolean;
  reason: TUIChangeReason;
}) => {
  const { userId, streamType, hasVideo } = eventInfo;
  // Handle flow layout when screen sharing flow changes
  if (streamType === TUIVideoStreamType.kScreenStream) {
    if (hasVideo) {
      enlargeStream.value =
        userId === basicStore.userId
          ? roomStore.localScreenStream
          : roomStore.streamInfoObj[`${userId}_${streamType}`];
      if (
        enlargeStream.value &&
        [LAYOUT.RIGHT_SIDE_LIST, LAYOUT.TOP_SIDE_LIST].indexOf(layout.value) ===
          -1
      ) {
        basicStore.setLayout(LAYOUT.RIGHT_SIDE_LIST);
      }
      if (userId !== basicStore.userId) {
        roomStore.setHasOtherScreenShare(true);
      }
    } else {
      if (userId === enlargeStream.value?.userId) {
        handleLargeStreamLeave();
      }
      if (userId !== basicStore.userId) {
        roomStore.setHasOtherScreenShare(false);
      }
      logger.debug(
        `${logPrefix} onUserVideoStateChanged: stop`,
        userId,
        streamType
      );
    }
  }
};

// Wheat level changes
const onSeatListChanged = (eventInfo: {
  seatList: TUISeatInfo[];
  seatedList: TUISeatInfo[];
  leftList: TUISeatInfo[];
}) => {
  const { leftList } = eventInfo;
  const leftUserIdList = leftList.map(item => item.userId);
  // When the user with the largest screen logs in, the user with the largest screen needs to be replaced.
  if (
    enlargeStream.value &&
    leftUserIdList.includes(enlargeStream.value?.userId)
  ) {
    handleLargeStreamLeave();
  }
};

// Remote user leaves
const onRemoteUserLeaveRoom = (eventInfo: { userInfo: TUIUserInfo }) => {
  const {
    userInfo: { userId },
  } = eventInfo;
  if (userId === enlargeStream.value?.userId) {
    handleLargeStreamLeave();
  }
};

// Handle large window stream leaving
const handleLargeStreamLeave = () => {
  if (roomStore.remoteStreamList.length === 0) {
    basicStore.setLayout(LAYOUT.NINE_EQUAL_POINTS);
    enlargeStream.value = null;
  } else {
    [enlargeStream.value] = roomStore.remoteStreamList;
  }
};

TUIRoomEngine.once('ready', () => {
  roomEngine.instance?.on(
    TUIRoomEvents.onRemoteUserLeaveRoom,
    onRemoteUserLeaveRoom
  );
  roomEngine.instance?.on(TUIRoomEvents.onSeatListChanged, onSeatListChanged);
  roomEngine.instance?.on(
    TUIRoomEvents.onUserVideoStateChanged,
    onUserVideoStateChanged
  );
});

onUnmounted(() => {
  roomEngine.instance?.off(
    TUIRoomEvents.onRemoteUserLeaveRoom,
    onRemoteUserLeaveRoom
  );
  roomEngine.instance?.off(TUIRoomEvents.onSeatListChanged, onSeatListChanged);
  roomEngine.instance?.off(
    TUIRoomEvents.onUserVideoStateChanged,
    onUserVideoStateChanged
  );
});
</script>

<style lang="scss" scoped>
  .tui-stream-container {
    width: 100%;
    height: 100%;

    .avatar-region {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;

      .avatar {
        width: 10rem;
        height: 10rem;
      }
    }
  }
</style>
