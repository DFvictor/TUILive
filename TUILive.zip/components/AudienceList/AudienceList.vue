<template>
  <div
    class='audience-container'
  >
    <div class='audience-title'>
      <span>{{t('Online audience')}}</span>
      <span class="audience-length">({{ audienceList.length }})</span>
    </div>
    <div class='audience-list'>
      <div
        class='audience-item'
        v-for='audience in audienceList'
        :key='audience.userId'
      >
        <div class='audience-avatar'>
          <Avatar :img-src='audience.avatarUrl' />
        </div>
        <span class='audience-name'>{{ audience.userName || audience.userId }}</span>
        <AudienceLevel :level="0" />
      </div>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { storeToRefs } from 'pinia';
import { useRoomStore } from '../../stores/room';
import { useI18n } from '../../locales';
import Avatar from '../common/Avatar.vue';
import AudienceLevel from '../common/AudienceLevel.vue'

const { t } = useI18n();
const roomStore = useRoomStore();
const { audienceList } = storeToRefs(roomStore);
</script>

<style lang="scss" scoped>
$audience-title-height: 3rem;
$audience-item-height: 3rem;
$collapse-section-height: 2rem;
$audience-container-padding: 1rem;
$audience-container-collapse-height: calc($audience-item-height * 3 + $audience-container-padding * 2 + $audience-title-height + $collapse-section-height);
$audience-container-unfold-height: calc($audience-item-height * 10 + $audience-container-padding * 2 + $audience-title-height + $collapse-section-height);

.audience-container {
  position: relative;
  width: 100%;
  height: 100%;
  padding: 0.5rem;
  background-color: #1F2024;

  .audience-title {
    height: $audience-title-height;
    border-bottom: 1px solid #3A3C42;
    font-weight: 600;
    line-height: $audience-title-height;
    color: rgba(255, 255, 255, 0.9);

    .audience-length {
      margin-left: 0.25rem;
      color: rgba(255, 255, 255, 0.55);
    }
  }

  .audience-list {
    height: calc(100% - 3rem);
    overflow-y: auto;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.9);

    .audience-avatar {
      flex-shrink: 0;
      width: 1.5rem;
      height: 1.5rem;
    }

    .audience-item {
      display: flex;
      align-items: center;
      height: 1.5rem;
      margin: 0.625rem;

      .audience-name {
        display: inline-block;
        margin: 0 0.75rem;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        max-width: 16rem;
      }
    }
  }

  .collapse-section {
    display: flex;
    align-items: center;
    justify-content: center;
    position: absolute;
    left: 1rem;
    bottom: 0;
    border-top: 1px solid rgba(255, 255, 255, 0.06);
    border-bottom: none;
    color: rgba(255, 255, 255, 0.3);
    height: 2rem;
    width: calc(100% - $audience-container-padding * 2);
    border-top: 1px solid rgba(255, 255, 255, 0.06);
    left: 1rem;
    bottom: 0;
    color: rgba(255, 255, 255, 0.3);
    cursor: pointer;
  }
}
</style>
