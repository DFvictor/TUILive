<template>
  <div class="tui-audience-list-h5">
    <div class="audience-list-button" @click="handleDisplayPopup">
      <div class="audience-list">
        <div v-for="(audience, index) in audienceList">
          <Avatar class="audience-item" v-if="index < 2" :img-src="audience.avatarUrl ? audience.avatarUrl : defaultAvatarImage" />
        </div>
      </div>
      <div class="audience-count">{{ audienceList.length }}</div>
    </div>
    <div ref="audiencePopupElement" @transitionend="handleTransitionEnd" :class="['audience-popup', { 'display-popup': isDisplayPopup }]">
      <div class='audience-popup-header'>
        <SvgIcon class="svg-icon" size="12" :icon="ArrowStrokeBackIcon" @click="handleCollapsePopup" />
        <div class="audience-popup-title">{{ t('Online audience') }} ({{ audienceList.length }})</div>
      </div>
      <div class='audience-popup-list'>
        <div class='audience-popup-item' v-for='audience,index in audienceList' :key='audience?.userId'>
          <Avatar v-if="index < MAX_RENDER_AUDIENCE_COUNT" class='audience-popup-avatar' :img-src='audience?.avatarUrl' />
          <div v-if="index < MAX_RENDER_AUDIENCE_COUNT" class="audience-popup-info">
            <span class='audience-popup-name'>{{ audience?.userName || audience?.userId }}</span>
            <AudienceLevel :level="0" />
          </div>
        </div>
      </div>
    </div>
    <div v-show="isDisplayPopup" class="audience-popup-mask" @click="handleCollapsePopup"></div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { storeToRefs } from 'pinia';
import { useRoomStore } from '../../stores/room';
import Avatar from '../common/Avatar.vue';
import AudienceLevel from '../common/AudienceLevel.vue'
import SvgIcon from '../common/base/SvgIcon.vue';
import ArrowStrokeBackIcon from '../common/icons/ArrowStrokeBackIcon.vue';
import { useI18n } from '../../locales';
import defaultAvatarImage from '../../assets/imgs/avatar.png';
import { MAX_RENDER_AUDIENCE_COUNT } from '../../constants/render';

const { t } = useI18n();
const isDisplayPopup = ref(false);
const roomStore = useRoomStore();
const { audienceList } = storeToRefs(roomStore);
const audiencePopupElement = ref<HTMLElement>();

const handleDisplayPopup = () => {
  isDisplayPopup.value = true;
  if (!audiencePopupElement.value) return;
  audiencePopupElement.value.style.transition = 'transform 0.4s';
}

const handleCollapsePopup = () => {
  isDisplayPopup.value = false;
}

const handleTransitionEnd = (event: TransitionEvent) => {
  if (event.propertyName === 'transform') {
    if (!isDisplayPopup.value) {
      if (!audiencePopupElement.value) return;
      audiencePopupElement.value.style.transition = 'none';
    }
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

.tui-audience-list-h5 {
  .audience-list-button {
    display: flex;
    justify-content: end;
    width: 5rem;
    height: 1.5rem;
    cursor: pointer;

    .audience-list {
      display: flex;
    }

    .audience-item,
    .audience-count {
      display: flex;
      justify-content: center;
      align-items: center;
      flex-shrink: 0;
      width: 1.5rem;
      height: 1.5rem;
      margin: 0 0.125rem;
      border-radius: 50%;
      font-size: 0.75rem;
      font-weight: 500;
    }

    .audience-count {
      background-color: rgba(0, 0, 0, 0.25);
    }
  }

  .audience-popup-mask {
    position: absolute;
    width: 200vw;
    height: 200vh;
    z-index: $levelFourZIndex;
    background-color: rgba(0, 0, 0, 0.55);
    transform: translate(calc(-100vw + 7.5rem), -5rem);
  }

  .audience-popup {
    position: absolute;
    padding: 1rem;
    z-index: $topLayerZIndex;
    background-color: rgb(31, 32, 36);

    .audience-popup-header {
      display: flex;
      justify-content: center;
      align-items: center;
      position: relative;
      margin-bottom: 1rem;
      font-weight: 500;

      .svg-icon {
        position: absolute;
        left: 0.5rem;
        cursor: pointer;
      }
    }

    .audience-popup-list {
      position: relative;
      height: calc(100% - 3rem);
      padding: 0.5rem;
      overflow-x: hidden;
      overflow-y: auto;
      font-weight: 500;
      font-size: 1rem;

      .audience-popup-avatar {
        flex-shrink: 0;
        width: 2.5rem;
        height: 2.5rem;
      }

      .audience-popup-item {
        display: flex;
        align-items: center;
        height: 3.5rem;
        margin: 0.625rem;

        .audience-popup-info {
          display: flex;
          align-items: center;
          width: 100%;
          padding: 0.75rem 0;
          margin-left: 0.75rem;
          border-bottom: 1px solid #3A3C42;

          .audience-popup-name {
            display: inline-block;
            margin-right: 0.75rem;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            max-width: 16rem;
          }
        }
      }
    }
  }
}

@media screen and (orientation: portrait) {
  .audience-popup {
    width: 100vw;
    height: 90vh;
    transform: translate(calc(-100vw + 7.5rem), calc(100vh - 1.5rem));
  }

  .audience-popup.display-popup {
    width: 100vw;
    height: 90vh;
    transform: translate(calc(-100vw + 7.5rem), calc(10vh - 1.5rem));
    transition: transform $popupTransitionTime;
  }
}

@media screen and (orientation: landscape) {
  .audience-popup {
    width: 50vw;
    height: 100vh;
    transform: translate(7.5rem, -3rem);
  }

  .audience-popup.display-popup {
    width: 50vw;
    height: 100vh;
    transform: translate(calc(-50vw + 7.5rem), - 3rem);
    transition: transform $popupTransitionTime;
  }
}
</style>