<template>
  <div class="tui-attention-anchor-floating">
    <div class="anchor-info">
      <Avatar class="anchor-avatar" :img-src="avatarUrl" />
      <div class="anchor-name">
        {{ roomName }}
      </div>
    </div>
    <div v-if="isAudience" @click="handleFollowAnchor" :class="['follow-button', { following: isFollow }]" >
      {{ isFollow ? t('Following') : t('Follow') }}
    </div>
  </div>
</template>

<script lang="ts" setup>
import { ref } from 'vue';
import { useRoomStore } from '../../stores/room.ts';
import Avatar from '../common/Avatar.vue';
import { useI18n } from '../../locales/index.ts';
import TUIMessage from '../common/base/Message/index';

const { t } = useI18n();
const { roomName, getAnchorUserInfo, isAudience } = useRoomStore();
const { avatarUrl } = getAnchorUserInfo();

const isFollow = ref(false);

const handleFollowAnchor = () => {
  isFollow.value = !isFollow.value;
  if (isFollow.value) {
    TUIMessage({
      type: 'success',
      message: t('Follow successfully'),
    })
  } else {
    TUIMessage({
      type: 'success',
      message: t('UnFollow successfully'),
    })
  }
}
</script>

<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

.tui-attention-anchor-floating {
  display: flex;
  align-items: center;
  width: 23rem;
  height: 2rem;
  border-radius: 2.5rem;
  color: #ffffff;
  font-weight: bold;
  z-index: $levelOneZIndex;;

  .anchor-info {
    display: flex;
    align-items: center;

    .anchor-avatar {
      flex-shrink: 0;
      width: 2rem;
      height: 2rem;
      margin: 0 0.5rem 0 0.25rem;
      border-radius: 50%;
    }

    .anchor-name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: rgba(255, 255, 255, 0.9);
    }
  }

  .follow-button {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-left: 0.5rem;
    width: 5.5rem;
    height: 2rem;
    border-radius: 1rem;
    background-color: #4086FF;
    cursor: pointer;
    user-select: none;
  }

}

.follow-button.following {
    background-color: #b4b4b4;
}


@media screen and (width >= $h5Breakpoint) {
  .anchor-name {
    max-width: 13rem;
  }
}

@media screen and (width < $h5Breakpoint) {
  .tui-attention-anchor-floating {
    width: 10.625rem;
    height: 2.5rem;
    font-weight: 500;
    font-size: 0.75rem;
    background-color: rgba(0, 0, 0, 0.25);

    .anchor-name {
      max-width: 4rem;
    }

    .follow-button {
      position: absolute;
      right: 0.5rem;
      max-width: 3.75rem;
      height: 1.5rem;
      margin-left: 3rem;
      border-radius: 1.5rem;
    }
  }
}
</style>