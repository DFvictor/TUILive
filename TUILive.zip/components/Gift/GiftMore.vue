<template>
  <div class="gift-more" v-if="isAudience">
    <div class="gift-icon">
       <img src="../../assets/imgs/gift-more.png" alt="">
    </div>
    <span class="gift-name">
      <span>{{ t('More') }}</span>
      <SvgIcon class="svg-icon" size="12" :icon="ArrowStrokeBackIcon"  />
    </span>
    <span class="recharge-button" @click="handleRechargeMoney">
      <SvgIcon class="recharge-icon" :icon="WalletIcon"/>
      <span>
        {{ `${t('Recharge')}(${localUser.money})` }}
      </span>
    </span>
  </div>
</template>
<script setup lang="ts">
import { useRoomStore } from "../../stores/room";
import { useI18n } from '../../locales';
import SvgIcon from '../common/base/SvgIcon.vue';
import WalletIcon from "../common/WalletIcon.vue";
import ArrowStrokeBackIcon from '../common/icons/ArrowStrokeBackIcon.vue';
import TUIMessage from '../common/base/Message/index';
import { SingleRechargeAmount } from "../../constants/giftConfig";

const { t } = useI18n();
const { localUser, rechargeMoney, isAudience } = useRoomStore();

const handleRechargeMoney = (event: Event) => {
  event.stopPropagation();
  const result = rechargeMoney(localUser.userId, SingleRechargeAmount);
  if (result) {
    TUIMessage({
      type: 'success',
      message: t('Recharge successful')
    })
  } else {
    TUIMessage({
      type: 'error',
      message: t('Recharge failed')
    })
  }
}
</script>
<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

@media screen and (width >= $h5Breakpoint) {
  .gift-more {
    display: flex;
    flex-shrink: 0;
    flex-direction: column;
    align-items: center;
    width: 6rem;
    height: 6rem;
    padding-top: 0.5rem;
    margin-right: 1rem;
    cursor: pointer;

    .gift-icon {
      display: flex;
      justify-content: center;
      align-items: center;

      border-radius: 50%;
      background-color: rgb(122, 101, 250);
      -webkit-user-drag: none;

      img {
        width: 3.125rem;
        height: 3.125rem;
      }
    }

    .gift-name {
      display: inline-block;
      width: 100%;
      height: 1.375rem;
      text-align: center;
      margin: 0.6rem 0 0.25rem 0;
      font-size: 0.875rem;

      .svg-icon {
        rotate: 180deg;
      }
    }

    .recharge-button {
      display: flex;
      justify-content: space-evenly;
      align-items: center;
      flex-shrink: 0;
      max-widthth: 7.5rem;
      height: 1.5rem;
      padding: 0 0.5rem;
      border-radius: 1.5rem;
      font-size: 0.75rem;
      text-wrap: nowrap;
      cursor: pointer;
      background-color: rgb(58, 60, 66);

      .recharge-icon {
        flex-shrink: 0;
        margin-right: 0.25rem;
      }

    }
  }
}

@media screen and (width < $h5Breakpoint) {
  .gift-more {

    .gift-icon {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 2rem;
      height: 2rem;
      border-radius: 50%;
      background-color: rgb(122, 101, 250);

      img {
        width: 2.25rem;
        height: 2.25rem;
      }
    }

    .gift-name {
      display: none;
    }

    .recharge-button {
      display: none;
    }
  }
}

</style>