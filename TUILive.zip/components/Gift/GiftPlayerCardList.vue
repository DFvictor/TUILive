<template>
  <Teleport to="body">
    <div class="tui-gift-player-list">
      <transition-group name="gift-list">
        <GiftPlayerCard class="gift-card-item" v-for="item, index in giftCardManager.playList.value" :key="item.id" :data-index="index" :data="item"
          :style="{ '--index': index }" />
      </transition-group>
    </div>
    <div id="svg-special-effects"></div>
  </Teleport>
</template>

<script lang="ts" setup>
import { useGiftCardManager } from "./useGiftPlayerCard";
import GiftPlayerCard from "./GiftPlayerCard.vue";

const giftCardManager = useGiftCardManager();
</script>

<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

#svg-special-effects {
  $minSize: min(100vw, 100vh);
  width: $minSize;
  height: $minSize;
  position: absolute;
  left: 50vw;
  top: 50vh;
  transform: translate(-50%, -50%);
  z-index: $topLayerZIndex;
  pointer-events: none;
}

.tui-gift-player-list {
  position: absolute;
  bottom: 50vh;
  width: 100vw;

  .gift-card-item {
    position: relative;
    margin: 2rem 0;
  }
}

.gift-list-enter-from {
  transform: translateX(-100%);
}

.gift-list-leave-to {
  opacity: 0;
  transform: translateY(-1.5rem);
}

.gift-list-enter-to,
.gift-list-leave-from {
  opacity: 1;
}

.gift-list-move,
.gift-list-enter-active,
.gift-list-leave-active {
  position: relative;
  transition: all .3s ease;
}

.gift-list-leave-active {
  position: absolute;
}

.gift-list-enter-active {
  transition-delay: calc(var(--index) * 0.05s);
}
</style>