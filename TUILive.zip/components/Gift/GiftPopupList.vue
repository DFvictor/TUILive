<template>
  <div class="tui-gift-list" v-if="isAudience" >
    <div class="gift-item-area">
      <div class="gift-item" @click="handleSelectGift(item)" v-for="item,index in giftList" :key="index" :class="selectedGift === item ? 'active' : ''">
        <div class="img-wrapper" id="img-wrapper">
          <img :src="item.imageUrl" :alt="item.giftName">
        </div>
        <span class="gift-name" @click="handleSendSelectedGift(item)">{{ selectedGift === item ? t('Send') : getGiftName(item) }}</span>
        <span class="gift-price">{{ item.price }}</span>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { onMounted, onUnmounted, ref } from "vue";
import { useGiftList, type Gift } from "./useGiftList";
import TUIMessage from '../common/base/Message/index';
import { useRoomStore } from "../../stores/room";
import { useI18n } from "../../locales";

const giftList = ref<Gift[]>([]);
const selectedGift = ref<Gift>({} as Gift);
const { getGiftList, handleSendGift, getGiftName } = useGiftList();
const { isAudience } = useRoomStore();
const { t } = useI18n();

const handleSelectGift = (gift: Gift) => { 
  selectedGift.value = gift;
}

const handleSendSelectedGift = async (gift: Gift) => {
  if (selectedGift.value !== gift) return;
  try {
    await handleSendGift(gift);
    selectedGift.value = {} as Gift;
  } catch (error) {
    TUIMessage({
      type: 'error',
      message: t('Insufficient balance, please recharge')
    })
    selectedGift.value = {} as Gift;
  }
}

onMounted(async () => {
  giftList.value = await getGiftList();
})

onUnmounted(() => {
  selectedGift.value = {} as Gift;
})
</script>
<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

$giftSizeWidth: 5rem;
$giftSizeHeight: 8rem;

.tui-gift-list {
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  overflow: hidden;
  border: 1px solid #48494F;
  border-radius: 1rem;
  background-color: #1F2024;
  

  .gift-title {
    display: none;
  }

  .gift-item-area {
    display: grid;
    grid-template-columns: repeat(auto-fit, $giftSizeWidth);
    grid-template-rows: repeat(auto-fit, $giftSizeHeight);
    width: 35.5rem;
    height: 100%;
    overflow: hidden;

    .gift-item {
      display: flex;
      flex-shrink: 0;
      flex-direction: column;
      align-items: center;
      width: $giftSizeWidth;
      height: $giftSizeWidth;
      margin: 1.5rem 0;
      cursor: pointer;

      img {
        width: 3.125rem;
        height: 3.125rem;
        -webkit-user-drag: none;
      }

      .gift-name {
        display: inline-block;
        text-wrap: nowrap;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-shrink: 0;
        width: 100%;
        height: 1.375rem;
      }

      .gift-price {
        display: inline-block;
        text-wrap: nowrap;
        height: 1.25rem;
        color: rgba(255, 255, 255, 0.55);
      }
    }
  }
}

@media  screen and (width >= $h5Breakpoint) {
  .gift-item {
    padding-top: 0.5rem;

    .gift-name {
      margin: 0.25rem 0;
    }
  }

  #img-wrapper::after, #img-wrapper::before {
    border-bottom: 0.1875rem solid transparent;
  }
}

.active {
  position: relative;
  $borderRadius: 0.625rem;
  $activeColor: rgb(64, 134, 255);

  .gift-name {
    width: 100%;
    text-align: center;
    border-bottom-left-radius: $borderRadius;
    border-bottom-right-radius: $borderRadius;
    background-color: $activeColor;
    cursor: pointer;
  }

  .img-wrapper::after, .img-wrapper::before {
    position: absolute;
    left: 0;
    top: 0;
    content: "";
    width: 100%;
    height: 4.5rem;
    border-radius: $borderRadius;
    background-color: transparent;
    border:0.1875rem solid $activeColor;
  }

  .img-wrapper::before {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }
}

</style>