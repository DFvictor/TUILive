<template>
  <div class="tui-gift-list" v-if="isAudience" >
    <div class="gift-title">
      <span class="title">{{ t('Gift') }}</span>
      <span class="recharge-button" @click="handleRechargeMoney">
        <SvgIcon class="recharge-icon" :icon="WalletIcon"/>
        <span>
          {{ `${t('Recharge')}(${localUser.money})` }}
        </span>
      </span>
    </div>
    <div class="gift-item-area">
      <div
      :class="['gift-item', {active: selectedGift === item}]" @click="handleSelectGift(item)" v-for="item,index in giftList" :key="index">
        <div class="img-wrapper">
          <img :src="item.imageUrl" :alt="item.giftName">
        </div>
        <span class="gift-name" @click="handleSendSelectedGift(item)">{{ selectedGift === item ? t('Send') : getGiftName(item) }}</span>
        <span class="gift-price">{{ item.price }}</span>
      </div>
    </div>
  </div>
</template>
<script setup lang="ts">
import { onMounted, onUnmounted, ref } from "vue";
import { useGiftList, type Gift } from "./useGiftList";
import WalletIcon from "../common/WalletIcon.vue";
import SvgIcon from "../common/base/SvgIcon.vue";
import TUIMessage from '../common/base/Message/index';
import { useRoomStore } from "../../stores/room";
import { useI18n } from "../../locales";
import { SingleRechargeAmount } from "../../constants/giftConfig";

const giftList = ref<Gift[]>([]);
const selectedGift = ref<Gift>({} as Gift);
const { getGiftList, handleSendGift, getGiftName } = useGiftList();
const { localUser, rechargeMoney, isAudience } = useRoomStore();
const { t } = useI18n();

const handleSelectGift = (gift: Gift) => { 
  selectedGift.value = gift;
}

const handleSendSelectedGift = async (gift: Gift) => {
  if (selectedGift.value !== gift) return;
  try {
    await handleSendGift(gift);
    selectedGift.value = {} as Gift;
  } catch (error) {
    TUIMessage({
      type: 'error',
      message: t('Insufficient balance, please recharge')
    })
    selectedGift.value = {} as Gift;
  }
}

const handleRechargeMoney = () => {
  const result = rechargeMoney(localUser.userId, SingleRechargeAmount);
  if (result) {
    TUIMessage({
      type: 'success',
      message: t('Recharge successful')
    })
  } else {
    TUIMessage({
      type: 'error',
      message: t('Recharge failed')
    })
  }
}

onMounted(async () => {
  giftList.value = await getGiftList();
})

onUnmounted(() => {
  selectedGift.value = {} as Gift;
})
</script>
<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

$giftSizePC: 5rem;
$giftListWidthPC: calc(100% - $giftSizePC);
$displayGiftCount : 12;
$giftGapPC: calc((100% - $displayGiftCount * $giftSizePC) / ($displayGiftCount * 2));
$giftSizeH5: 4rem;
$giftGapH5: 0.25rem;

.tui-gift-list {
  display: flex;
  align-items: center;
  width: 100%;
  height: 100%;
  overflow: hidden;

  .gift-title {
    display: none;
  }

  .gift-item-area {
    display: flex;
    width: 100%;
    height: 100%;

    .gift-item {
      display: flex;
      flex-shrink: 0;
      flex-direction: column;
      align-items: center;
      width: $giftSizePC;
      height: $giftSizePC;
      margin: 0 $giftGapPC;
      cursor: pointer;

      img {
        width: 3.125rem;
        height: 3.125rem;
        -webkit-user-drag: none;
      }

      .gift-name {
        display: inline-block;
        text-wrap: nowrap;
        text-align: center;
        overflow: hidden;
        text-overflow: ellipsis;
        flex-shrink: 0;
        width: 100%;
        height: 1.375rem;
      }

      .gift-price {
        display: inline-block;
        text-wrap: nowrap;
        height: 1.25rem;
        color: rgba(255, 255, 255, 0.55);
      }
    }
  }
}

@media  screen and (width >= $h5Breakpoint) {
  .gift-item {
    padding-top: 0.5rem;

    .gift-name {
      margin: 0.25rem 0;
    }
  }

  .gift-item.img-wrapper::after, .gift-item.img-wrapper::before {
    border-bottom: 0.1875rem solid transparent;
  }
}

.active {
  position: relative;
  $borderRadius: 0.625rem;
  $activeColor: rgb(64, 134, 255);

  .gift-name {
    width: 100%;
    text-align: center;
    border-bottom-left-radius: $borderRadius;
    border-bottom-right-radius: $borderRadius;
    background-color: $activeColor;
    cursor: pointer;
  }

  .img-wrapper::after, .img-wrapper::before {
    position: absolute;
    left: 0;
    top: 0;
    content: "";
    width: 100%;
    height: 4.5rem;
    border-radius: $borderRadius;
    background-color: transparent;
    border:0.1875rem solid $activeColor;
  }

  .img-wrapper::before {
    border-bottom-left-radius: 0;
    border-bottom-right-radius: 0;
  }
}

  @media screen and (width < $h5Breakpoint) {
    .tui-gift-list {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 20.75rem;
      background-color: rgb(31, 32, 36);
      font-size: 0.75rem;
      line-height: 1.25rem;

      .gift-title {
        display: flex;
        position: relative;
        justify-content: center;
        width: 100%;
        margin: 1rem 0;
        font-weight: 500;
        color: rgba(255,255,255,0.9);

        .title {
          font-size: 1rem;
        }

        .recharge-button {
          display: flex;
          justify-content: space-evenly;
          align-items: center;
          position: absolute;
          right: 1rem;
          height: 1.5rem;
          padding: 0 0.5rem;
          background-color: rgb(58, 60, 66);
          border-radius: 1.5rem;
          cursor: pointer;

          .recharge-icon {
            flex-shrink: 0;
            margin-right: 0.25rem;
          }

        }
      }
      .gift-item-area {
        display: grid;
        grid-template-columns: repeat(auto-fit, $giftSizeH5);
        justify-content: space-evenly;
        flex: 1;
        flex-wrap: wrap;
        overflow-y: auto;
        overflow-x: hidden;
        width: 100%;

        .gift-item {
          width: 4.5rem;
          height: 8.5rem;
          margin: 0 $giftGapH5;
          flex-shrink: 0;
          font-weight: 500;

          .img-wrapper {
            display: flex;
            align-items: center;
            justify-content: center;
            width: $giftSizeH5;
            height: $giftSizeH5;
            margin-bottom: 0.5rem;

            img {
              width: 3.25rem;
              height: 3.25rem;
            }
          }
        }
      }
    }

    .active {
      position: relative;
      $borderRadius: 0.625rem;
      $activeColor: rgb(64, 134, 255);

      .gift-name {
        width: 100%;
        text-align: center;
        border-bottom-left-radius: $borderRadius;
        border-bottom-right-radius: $borderRadius;
        background-color: $activeColor;
        cursor: pointer;
      }

      .img-wrapper::after, .img-wrapper::before {
        position: absolute;
        left: 0;
        top: 0;
        content: "";
        width: 100%;
        height: 4.5rem;
        border-radius: $borderRadius;
        background-color: transparent;
        border: 0.1875rem solid $activeColor;
      }

      .img-wrapper::before {
        border-bottom-left-radius: 0;
        border-bottom-right-radius: 0;
      }
    }

    @media screen and (orientation: portrait) {
      .gift-item-area {
        padding: 0 0.5rem;
      }
    }

    @media screen and (orientation: landscape) {
      .gift-item-area {
        padding: 0 1.5rem;
      }
    }
  }

</style>