import {
  provide,
  inject,
  InjectionKey,
  reactive,
  ComputedRef,
  computed,
} from "vue";
import SVGA from "svgaplayerweb";
import { Gift, GiftMsg } from "./useGiftList.ts";
import { safelyParse } from "../Chat/util.ts";
import { animationUrlReplaceContent, animationUrlReplaceTarget } from "../../constants/giftConfig.ts";

export interface GiftCardManager {
  isShowing: ComputedRef<boolean>;
  playList: ComputedRef<GiftCardMsg[]>;
  show: (data: any) => void;
  hide: () => void;
}

export interface GiftCardMsg {
  avatarUrl: string;
  senderName: string;
  giftName: string;
  giftName_en: string;
  giftUrl: string;
  animationUrl: string;
  giftId: string;
  userId: string;
  id: number;
}

export const safelyParseGiftMsgForPlayerCard = (
  giftMsg: string
): GiftCardMsg => {
  const giftMsgJson = safelyParse(giftMsg) as GiftMsg;
  const giftData = giftMsgJson.data.gift as unknown as Gift;
  const senderData = giftMsgJson.data.sender;
  return {
    avatarUrl: senderData.avatarUrl,
    senderName: senderData.userName,
    giftName: giftData.giftName,
    giftName_en: giftData.giftName_en || giftData.giftName,
    giftUrl: giftData.imageUrl,
    animationUrl: giftData.animationUrl,
    giftId: giftData.giftId,
    userId: senderData.userId,
    id: Date.now() + Math.random(),
  };
};

const GiftCardKey = Symbol() as InjectionKey<GiftCardManager>;

export function createGiftCardManager() {
  const state = reactive<{
    isShowing: boolean;
    playList: GiftCardMsg[];
  }>({
    isShowing: false,
    playList: [],
  });

  const manager: GiftCardManager = {
    isShowing: computed(() => state.isShowing),
    playList: computed(() => state.playList),
    async show(data: GiftCardMsg) {
      state.playList.push(data);
      if (data.animationUrl) {
        playSvgAnimation(data.animationUrl, "svg-special-effects");
      }
    },
    hide() {
      state.playList.shift();
    },
  };

  provide(GiftCardKey, manager);
  return manager;
}

const animationPlayList: string[] = [];
let isPlaying = false;
let player: SVGA.Player;
let parser: SVGA.Parser;
const svgaCache = new Map<string, SVGA.VideoEntity>();

function playSvgAnimation(url: string, canvasId: string) {
  if (!url || !canvasId) return;
  if (!player || !parser) {
    player = new SVGA.Player(`#${canvasId}`);
    parser = new SVGA.Parser();
  }
  player.loops = 1;

  player.onFinished(() => {
    isPlaying = false;
    if (animationPlayList.length > 0) {
      const nextUrl = animationPlayList.shift();
      startPlay(nextUrl!);
    }
  });

  startPlay(url);

  async function startPlay(url: string) {
    if (isPlaying) {
      animationPlayList.push(url);
      return;
    }
    try {
      const parseUrl = url.replace( animationUrlReplaceTarget, animationUrlReplaceContent );
      let videoItem = svgaCache.get(parseUrl);

      if (!videoItem) {
        videoItem = await new Promise((resolve, reject) => {
          parser.load(
            parseUrl,
            (item) => {
              svgaCache.set(parseUrl, item);
              resolve(item);
            },
            reject
          );
        });
      }
      if (!videoItem) throw Error("Failed to load SVGA animation:");
      player.setVideoItem(videoItem);
      player.startAnimation();
      isPlaying = true;
    } catch (error) {
      console.error(error);
    }
  }
}

export function useGiftCardManager() {
  const manager = inject(GiftCardKey);
  if (!manager) {
    throw new Error("useGiftCardManager must be used within a setup()");
  }
  return manager;
}