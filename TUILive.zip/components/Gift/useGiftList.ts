import { useBasicStore } from "../../stores/basic";
import { useRoomStore } from "../../stores/room";
import TUIMessage from '../common/base/Message/index';
import { safelyParseGiftMsgForPlayerCard, useGiftCardManager } from "./useGiftPlayerCard";
import useChatEditor from "../Chat/ChatEditor/useChatEditor";
import { useI18n } from "../../locales";
import { getLanguage } from '../../utils/common';

const { t } = useI18n();

const giftListDataBackup = {
  "giftList": [
    {
      "giftId": "1",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/huojian.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "火箭",
      "giftName_en": "Rocket",
      "type": 0
    },
    {
      "giftId": "2",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/kiss.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "吻",
      "giftName_en": "Kiss",
      "type": 0
    },
    {
      "giftId": "3",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/dianzan.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "点赞",
      "giftName_en": "Like",
      "type": 0
    },
    {
      "giftId": "4",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/bingqilin.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "冰淇淋",
      "giftName_en": "Ice-cream",
      "type": 0
    },
    {
      "giftId": "5",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/jidan.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "鸡蛋",
      "giftName_en": "Egg",
      "type": 0
    },
    {
      "giftId": "6",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/zhishengji.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "直升机",
      "giftName_en": "Helicopter",
      "type": 0
    },
    {
      "giftId": "7",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/bixin.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "比心",
      "giftName_en": "Heart gesture",
      "type": 0
    },
    {
      "giftId": "8",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/xiaoxiong.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "玩偶",
      "giftName_en": "Toy",
      "type": 0
    },
    {
      "giftId": "9",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/dangao.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "蛋糕",
      "giftName_en": "Cake",
      "type": 0
    },
    {
      "giftId": "10",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/youting.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "游艇",
      "giftName_en": "Yacht",
      "type": 0
    },
    {
      "giftId": "11",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/meigui.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "玫瑰",
      "giftName_en": "Rose",
      "type": 0
    },
    {
      "giftId": "12",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/jinsepaoche.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "豪华轿车",
      "giftName_en": "Luxury Sedan",
      "type": 0
    },
    {
      "giftId": "13",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/chibang.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "翅膀",
      "giftName_en": "Wings",
      "type": 0
    },
    {
      "giftId": "14",
      "imageUrl": "https://liteav.sdk.qcloud.com/app/res/picture/live/gift/jianianhua.png",
      "animationUrl": "",
      "price": 99,
      "giftName": "嘉年华",
      "giftName_en": "Carnival",
      "type": 0
    }
  ]
}

const giftNameColorList = ['#3074FD', '#3CCFA5', '#FF8607', '#F7AF97', '#FF8BB7', '#FC6091'];

export interface Gift {
  giftId: string;
  imageUrl: string;
  animationUrl: string;
  price: number;
  giftName: string;
  giftName_en: string;
  type: number;
}

export interface GiftMsg {
  businessID: 'TUIGift',
  data: {
      gift: {
          animationUrl: string,
          extInfo: {},
          giftId: string,
          giftName: string,
          giftName_en: string,
          imageUrl: string,
          price: number
      },
      giftCount: number,
      receiver: {
          avatarUrl: string,
          level: string,
          userId: string,
          userName: string
      },
      sender: {
          avatarUrl: string,
          level: string,
          userId: string,
          userName: string
      }
  },
  platform: string,
  version: string
}

async function safelyFetchGiftData(url: string) {
  try {
    const response = await fetch(url, {
      mode: 'no-cors',
      method: 'GET',
      headers: {
        contentType: 'application/json',
      }
    });
    if (!response.ok) {
      return giftListDataBackup;
    }
    return  await response.json();
  } catch (error) {
    TUIMessage({
      type: 'error',
      message: t('Fetch gift data failed'),
    });
    return {
      giftList: [] as Gift[]
    }
  }
}

export function useGiftList() {
  const basicStore = useBasicStore();
  const { sendGiftMsg } = useChatEditor();
  const { localUser, isAnchor, consumeMoney, getAnchorUserInfo } = useRoomStore();
  const giftCardManager = useGiftCardManager();
  const anchorUserInfo = getAnchorUserInfo();
  const language = getLanguage();

  const createGiftMsg = (gift: Gift): GiftMsg => {
    return {
      businessID: 'TUIGift',
      data: {
          gift: {
              animationUrl: gift.animationUrl,
              extInfo: {},
              giftId: gift.giftId,
              giftName: gift.giftName,
              giftName_en: gift.giftName_en,
              imageUrl: gift.imageUrl,
              price: gift.price
          },
          giftCount: 1,
          receiver:{
            avatarUrl: anchorUserInfo.avatarUrl ? anchorUserInfo.avatarUrl : '',
            level: '0',
            userId: anchorUserInfo.userId,
            userName: anchorUserInfo.userName ? anchorUserInfo.userName : ''
          },
          sender:{
            avatarUrl: basicStore.avatarUrl ? basicStore.avatarUrl : '',
            level: '0',
            userId: basicStore.userId,
            userName: basicStore.userName || basicStore.userId
          }
      },
      platform: 'Web',
      version: '1.0'
    }
  }
  
  const getGiftList = async (): Promise<Gift[]> => {
    const giftDataUrl = 'https://dldir1.qq.com/hudongzhibo/TRTC/TUIKit/Gift/gift_data.json';
    const { giftList } = await safelyFetchGiftData(giftDataUrl);
    return giftList;
  }

  const getGiftName = (gift: { giftName:string, giftName_en:string }) => { 
    return language === 'zh-CN' ? gift.giftName : gift.giftName_en;
  }

  const getGiftNameColor = () => {
    const index = Math.floor(Math.random() * 10 * giftNameColorList.length);
    return giftNameColorList[index % giftNameColorList.length];
  }

  const isSelfSend = (sender: {userId: string}) => basicStore.userId === sender.userId;

  const handleSendGift = async (gift: Gift) => {
    if (!gift || isAnchor) return;
    const giftMsg = createGiftMsg(gift);
    if (localUser.money >= gift.price) {
      try {
        await sendGiftMsg(giftMsg);
        const giftMsgForPlay = safelyParseGiftMsgForPlayerCard(giftMsg as unknown as string);
        giftCardManager.show(giftMsgForPlay);

        const result = consumeMoney(localUser.userId, gift.price);
        if (result) {
          TUIMessage({
            type: 'success',
            message: t('Gift sent successfully')
          })
        }
      } catch (error) {
        TUIMessage({
          type: 'error',
          message: t('Insufficient balance, please recharge')
        })
      }
    } else {
      TUIMessage({
        type: 'error',
        message: t('Insufficient balance, please recharge')
      })
    }
  }

  return {
    isSelfSend,
    getGiftName,
    getGiftNameColor,
    createGiftMsg,
    getGiftList,
    handleSendGift
  }
}