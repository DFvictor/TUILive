<template>
  <div class="gift-player-card">
    <div class="card-container">
      <div class="avatar">
        <Avatar :src="props?.data.avatarUrl" />
      </div>
      <div class="desc-text">
        <div class="sender-name">{{ getDisplayName() }}</div>
        <div class="gift-name">{{`${ getGiftName(props?.data) }`}}</div>
      </div>
      <transition name="gift-image">
        <div class="gift-display" v-if="isShowGiftImage">
          <img :src="props?.data.giftUrl" :alt="props?.data.giftName">
        </div>
      </transition>
    </div>
  </div>
</template>

<script lang="ts" setup>
import { defineProps, onBeforeUnmount, onMounted, ref } from "vue";
import { useGiftCardManager, type GiftCardMsg } from "./useGiftPlayerCard";
import Avatar from "../common/Avatar.vue";
import { useGiftList } from "./useGiftList";
import { useI18n } from "../../locales";

let hideGiftCardTimer: number | null = null;
let showGiftImageTimer: number | null = null;
const { t } = useI18n();
const isShowGiftImage = ref(false);
const { getGiftName, isSelfSend } = useGiftList();
const giftCardManager = useGiftCardManager();

const getDisplayName = () => {
  return isSelfSend({ userId: props?.data.userId }) ? t('I') : props?.data.senderName;
}

const props = defineProps<{
  data: GiftCardMsg;
}>();

onMounted(() => {
  hideGiftCardTimer = setTimeout(() => {
    giftCardManager.hide();
  }, 1000) as unknown as number;

  showGiftImageTimer = setTimeout(() => {
    isShowGiftImage.value = true;
  }, 300) as unknown as number;
})

onBeforeUnmount(() => {
  if (hideGiftCardTimer) {
    clearTimeout(hideGiftCardTimer);
    hideGiftCardTimer = null;
  }
  if(showGiftImageTimer) {
    clearTimeout(showGiftImageTimer);
    showGiftImageTimer = null;
  }
})
</script>

<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

.gift-player-card {
  width: 100%;
  height: 100%;
  color: rgba(255, 255, 255, 0.9);

  .card-container {
    display: flex;
    align-items: center;
    position: relative;
    width: 11rem;
    height: 2.5rem;
    padding: 0.25rem;
    border-radius: 2.5rem;
    background-color: rgba(0, 0, 0, 0.25);
    font-size: 0.75rem;

    .avatar {
      flex-shrink: 0;
      width: 2rem;
      height: 2rem;
    }

    .desc-text {
      display: flex;
      flex-direction: column;
      justify-content: space-evenly;
      flex-shrink: 0;
      width: 6rem;
      height: 2.5rem;
      margin: 0 0.5rem;

      .sender-name {
        width: 6rem;
        overflow: hidden;
        text-wrap: nowrap;
        text-overflow: ellipsis;
        font-weight: 500;
      }

      .gift-name {
        font-size: 0.625rem;
        color: rgba(255, 255, 255, 0.55);
      }

    }

    .gift-display {
      position: absolute;
      right: -2rem;
      bottom: -1rem;

      img {
        max-width: 5.5rem;
        max-height: 5.5rem;
      }
    }
  }
}


.gift-image-enter-active {
  transition: transform 0.5s ease;
}

.gift-image-enter-from {
  transform: translateX(-100vw);
}

.gift-image-enter-to {
  transform: translateX(0);
}


@media screen and (width >=$h5Breakpoint) {
  .gift-player-card {
    display: none;
  }
}

</style>