<template>
  <div class="chat-editor">
    <emoji class="chat-emoji" @choose-emoji="handleChooseEmoji" />
    <textarea
      ref="editorInputEle"
      v-model="sendMsg"
      :disabled="isMessageDisabled"
      class="content-bottom-input"
      :placeholder="
        isMessageDisabled ? t('Muted by the moderator') : t('Type a message')
      "
      @keyup.enter="sendMessage"
    ></textarea>
  </div>
</template>

<script setup lang="ts">
import emoji from '../EditorTools/emoji.vue';
import useChatEditor from './useChatEditor';
const {
  t,
  editorInputEle,
  sendMsg,
  isMessageDisabled,
  sendMessage,
  handleChooseEmoji,
} = useChatEditor();
</script>

<style lang="scss" scoped>
@import "../../../assets/style/variables.scss";

.chat-editor {  
  position: relative;
  box-sizing: border-box;
  display: flex;
  align-items: start;
  flex-shrink: 0;
  width: 100%;
  height: 3.25rem;
  padding: 0.5rem;
  border: 1px solid #3A3C42;
  border-radius: 0.5rem;

  .chat-emoji {
    display: flex;
    flex-shrink: 0;
    color: rgba(255, 255, 255, 0.55);
  }

  .content-bottom-input {
    box-sizing: border-box;
    position: absolute;
    left: 2rem;
    top: 0.25rem;
    height: calc(100% - 0.25rem * 2);
    width: calc(100% - 2rem * 2);
    font-family: 'PingFang SC';
    font-size: 0.875rem;
    font-weight: 400;
    line-height: 1.375rem;
    color: #ffffff;
    caret-color: #ffffff;
    resize: none;
    background: #1F2024;
    border: 1px solid transparent;
    border-radius: 0.5rem;

    &:focus-visible {
      outline: none;
    }

    &::placeholder {
      font-size: 0.875rem;
      font-weight: 400;
      line-height: 1.375rem;
      color: rgba(255, 255, 255, 0.30);
    }

    &::-webkit-scrollbar {
      display: none;
    }
  }
}

@media screen and (width < $h5Breakpoint) {
  .chat-editor {
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    margin: 0;
    width: 9rem;
    height: 2.5em;
    color: #F2F5FC;
    background-color: rgba(0,0,0,0.25);
    border: 1px solid rgba(255, 255, 255, 0.14);
    border-radius: 2.5rem;

    .chat-emoji {
      color: rgba(255, 255, 255, 0.7);
    }

    .content-bottom-input {
      position: relative;
      left: 0;
      top: 0;
      flex: 1;
      height: 1.5rem;
      margin: 0;
      color: #F2F5FC;
      background-color: transparent;
      line-height: 1rem;
    }
    .content-bottom-input::placeholder {
      color: rgba(242, 245, 252, 0.8);
      font-family: 'PingFang SC';
      font-weight: 400;
      font-size: 0.75rem;
      line-height: 1rem;
      white-space: nowrap;
    }
    .content-bottom-input:focus {
      border: none;
    }
  }
}
</style>