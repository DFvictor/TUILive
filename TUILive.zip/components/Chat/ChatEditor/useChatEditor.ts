import { ref, watch } from 'vue';
import { storeToRefs } from 'pinia';
import { TencentCloudChat } from '@tencentcloud/tuiroom-engine-js';
import { ChatSDK, type Message } from '@tencentcloud/chat';
import TUIMessage from '../../common/base/Message/index';
import useGetRoomEngine from '../../../hooks/useRoomEngine';
import { useChatStore } from '../../../stores/chat';
import { useRoomStore } from '../../../stores/room';
import { useI18n } from '../../../locales';
import { useBasicStore } from '../../../stores/basic';
import { decodeSendTextMsg } from '../util';
import { GiftMsg } from '../../Gift/useGiftList';

export default function useChatEditor() {
  const roomEngine = useGetRoomEngine();
  const basicStore = useBasicStore();
  const chatStore = useChatStore();
  const roomStore = useRoomStore();
  const { t } = useI18n();
  const { roomId } = storeToRefs(basicStore);
  const { isMessageDisabled } = storeToRefs(chatStore);
  const editorInputEle = ref();
  const sendMsg = ref('');
  const isEmojiToolbarVisible = ref(false);
  
  watch(isMessageDisabled, (value) => {
    if (value) {
      sendMsg.value = '';
    }
  });

  const createMessage = (tim: ChatSDK, message: string) => {
    return tim.createTextMessage({
      to: roomId.value,
      conversationType: TencentCloudChat.TYPES.CONV_GROUP,
      payload: {
        text: message,
      },
    });
  };

  const createGiftMessage = (tim: ChatSDK, giftMsg: GiftMsg) => { 
    const giftMsgString = JSON.stringify(giftMsg);
    return tim.createCustomMessage({
      to: roomId.value,
      conversationType: TencentCloudChat.TYPES.CONV_GROUP,
      payload: {
        data: giftMsgString,
        description: '',
        extension: ''
      },
    });
  }

  const sendMessage = async () => {
    try {
      let message: Message;
      const tim = roomEngine.instance?.getTIM();
      if (!tim) {
        throw new Error('tim is null');
      }

      let inputValue = decodeSendTextMsg(sendMsg.value);
      sendMsg.value = '';
      isEmojiToolbarVisible.value = false;
      if (inputValue === '') return;
      message = createMessage(tim, inputValue);

      await tim.sendMessage(message);
      chatStore.updateMessageList({
        ID: Math.random().toString(),
        type: 'TIMTextElem',
        payload: {
          text: message.payload.text,
        },
        nick:
          roomStore.localUser.nameCard ||
          roomStore.localUser.userName ||
          roomStore.localUser.userId,
        from: roomStore.localUser.userId,
        flow: 'out',
        sequence: Math.random(),
      });
    } catch (error) {
      TUIMessage({ type: 'error', message: t('Failed to send the message') });
    }
  };

  const sendGiftMsg = async (giftMsg: GiftMsg) => {
    try {
      const tim = roomEngine.instance?.getTIM();
      if (!tim) {
        throw new Error('tim is null');
      }

      const message = createGiftMessage(tim as ChatSDK, giftMsg);
      await tim.sendMessage(message);
      chatStore.updateMessageList({
        ID: Math.random().toString(),
        type: 'TIMTextElem',
        payload: {
          text: message.payload.data,
        },
        nick:
          roomStore.localUser.nameCard ||
          roomStore.localUser.userName ||
          roomStore.localUser.userId,
        from: roomStore.localUser.userId,
        flow: 'out',
        sequence: Math.random(),
      });
    } catch (error) {
      TUIMessage({ type: 'error', message: t('Failed to send the gift') });
    }
  }

  const handleChooseEmoji = (emojiName: string) => {
    sendMsg.value += emojiName;
    editorInputEle.value.focus();
  };
  const togglePopover = () => {
    isEmojiToolbarVisible.value = !isEmojiToolbarVisible.value;
  };
  return {
    t,
    editorInputEle,
    sendMsg,
    isMessageDisabled,
    sendMessage,
    sendGiftMsg,
    handleChooseEmoji,
    isEmojiToolbarVisible,
    togglePopover,
  };
}