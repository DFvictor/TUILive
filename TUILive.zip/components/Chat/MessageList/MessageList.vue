<template>
  <div
    class='message-list-container'
  >
    <div id='messageScrollList' ref='messageListRef' class='message-list'>
      <div
        v-for='item in messageList'
        :key='item.ID'
        ref='messageAimId'
        class='message-item'
      > 
        <div class="message-item-wrapper">
          <div v-if="!isGiftMsg(item.payload.text)" class='message-header' :title='item.nick || item.from'>
            <AudienceLevel v-if="!isMessageFromAnchor(item.from)" :level="0" />
            <div v-if="isMessageFromAnchor(item.from)" class="anchor-identity">{{ t('ANCHOR') }}</div>
          </div>
          <div class='message-body'>
            <span v-if="!isGiftMsg(item.payload.text)" class='audience-name'>{{ getDisplayName(item.from) }} : </span>
            <message-text :data='item.payload.text' />
          </div>
        </div>
      </div>
    </div>
    <GiftPlayerCardList class="gift-card-player-area" />
  </div>
</template>

<script setup lang="ts">
import { nextTick, onMounted, onUnmounted, ref, watch } from 'vue';
import { storeToRefs } from 'pinia';
import { TUIRole } from '@tencentcloud/tuiroom-engine-js';
import AudienceLevel from '../../common/AudienceLevel.vue';
import MessageText from '../MessageTypes/MessageText.vue';
import GiftPlayerCardList from '../../Gift/GiftPlayerCardList.vue';
import useMessageList from './useMessageListHook';
import { getScrollInfo } from '../../../utils/domOperation';
import { throttle } from '../../../utils/utils';
import { useRoomStore } from '../../../stores/room';
import { isGiftMsg } from '../util';
import { useI18n } from '../../../locales';

const messageListRef = ref<HTMLElement>();
const roomStore = useRoomStore();
const { getDisplayName } = storeToRefs(roomStore);
const { t } = useI18n();
const {
  messageList,
  setMessageListInfo,
  handleGetHistoryMessageList,
  isCompleted,
} = useMessageList();
let isScrollAtBottom = true;

const isMessageFromAnchor = (from: string) => {
  return roomStore.getUserRole(from) === TUIRole.kRoomOwner
}

const handleMessageListScroll = (e: Event) => {
  const messageContainer = e.target as HTMLElement;
  const bottom =
    messageContainer.scrollHeight -
    messageContainer.scrollTop -
    messageContainer.clientHeight;
  isScrollAtBottom = bottom <= 80;
  if (messageContainer.scrollTop < 40 && !isCompleted.value) {
    handleGetHistoryMessageList();
  }
};

const handleScroll = throttle(handleMessageListScroll, 1000);

async function scrollToLatestMessage() {
  const { scrollHeight } = await getScrollInfo('#messageScrollList');
  if (messageListRef.value) {
    messageListRef.value.scrollTop = scrollHeight;
  }
}

watch(messageList, async (newMessageList, oldMessageList) => {
  if ((newMessageList as any).length === 0) return;
  const lastMessage = (newMessageList as any).slice(-1);
  const oldLastMessage = (oldMessageList as any).slice(-1);
  const isSendByMe = lastMessage[0].flow === 'out';
  const isNewMessage = lastMessage[0].ID !== oldLastMessage[0]?.ID;
  await nextTick();
  if (isScrollAtBottom) {
    scrollToLatestMessage();
    return;
  }
  if (isSendByMe && isNewMessage) {
    scrollToLatestMessage();
  }
});

onMounted(() => {
  setMessageListInfo();
  messageListRef.value?.addEventListener('scroll', handleScroll);
});

onUnmounted(() => {
  messageListRef.value?.removeEventListener('scroll', handleScroll);
});
</script>

<style lang="scss" scoped>
@import '../../../assets/style/variables.scss';
.tui-theme-white .message-body {
  --user-chat-color: rgba(213, 224, 242, 0.4);
  --user-font-color: var(--black-color);
  --host-font-color: var(--white-color);
}

.tui-theme-black .message-body {
  --user-chat-color: rgba(213, 224, 242, 0.1);
  --user-font-color: var(--background-color-4);
  --host-font-color: var(--background-color-4);
}

.message-list-container {
  flex: 1;
  width: 100%;
  overflow: hidden;

  .message-list {
    padding: 0 0.5rem;
    margin-bottom: 0.5rem;
    height: 100%;
    overflow: hidden auto;

    &::-webkit-scrollbar {
      display: none;
    }
  }

  .message-top {
    display: flex;
    justify-content: center;
  }

  .message-item{
    width: 100%;
    background-color: transparent;

    .message-item-wrapper {
      display: inline-flex;
      align-items: start;
      margin: 0.5rem 0;
      line-height: 1.25rem;
      font-size: 0.75rem;
      font-weight: 500;

      .message-header {
        display: flex;
        align-items: center;
        margin-right: 0.5rem;

        .audience-name {
          margin-left: 0.5rem;
          white-space: nowrap;
        }

        .anchor-identity {
          padding: 0 0.5rem;
          height: 1.125rem;
          line-height: 1.125rem;
          border-radius: 1.125rem;
          background-color: #4D8EFF;
          font-weight: 700;
          white-space: nowrap;
        }
      }

      .message-body {
        word-break: break-all;
        color: rgba(255, 255, 255, 0.9);
      }
    }
  }

}

@media screen and (width < $h5Breakpoint) {
  ::-webkit-scrollbar {
    width: 0;
  }

  ::-webkit-scrollbar-track {
    background: transparent; 
  }

  ::-webkit-scrollbar-thumb {
    background: transparent; 
  }

  ::-webkit-scrollbar-thumb:hover {
    background: transparent;
  }

  .message-list-container {
    flex: 1;
    position: relative;
    width: 100%;
    height: 80%;
    background-color: transparent;

    .message-item .message-item-wrapper {
      border-radius: 1.125rem;
      padding: 0.5rem;
      margin: 0.125rem 0;
      background-color: rgba(0, 0, 0, 0.25);
    }

    .gift-card-player-area {
      position: absolute;
      left: 0;
      top: 0;
      transform: translateY(-100%);
      width: 100vw;
      pointer-events: none;
    }
  }

  .gift-player-card {
    position: absolute;
    left: 0;
    top: 0;
  }
}
</style>