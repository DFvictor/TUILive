<template>
  <div class="chat-container">
      <span class="message-title">{{ t("Message list") }}</span>
      <message-list />
      <chat-editor />
  </div>
</template>

<script setup lang="ts">
import { useI18n } from '../../locales';
import MessageList from './MessageList/MessageList.vue';
import ChatEditor from './ChatEditor/ChatEditor.vue';

const { t } = useI18n();
</script>

<style lang="scss" scoped>
@import "../../assets/style/variables.scss";

.chat-container {
  display: flex;
  flex-direction: column;
  position: relative;
  height: 100%;
  width: 100%;
  padding: 0.5rem;
  background-color: #1F2024;

  .message-title {
    height: 3rem;
    line-height: 3rem;
    border-bottom: 1px solid #3A3C42;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.9);
  }
}

@media screen and (width < $h5Breakpoint) {
  .chat-container {
    display: flex;
    background-color: transparent;

    .message-title {
      display: none;
    }
  }

}
</style>