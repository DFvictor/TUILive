<template>
  <span>
    <span
      v-for="(item, index) in handleTextMessageShowContext(props.data)"
      :key="index"
    >
      <span v-if="item.name === 'text'" class="text-box">{{ item.text }}</span>
      <img v-else-if="item.name === 'img'" class="text-img" :src="item.src" />
      <span v-else-if="item.name ==='gift'" class="text-gift">
        <span class="gift-sender">{{ `${isSelfSend(item.giftData.sender) ? t('I') : item.giftData.sender.userName} `  }}</span>
        <span> {{  `${t('send')} ` }}</span>
        <span class="gift-receiver"> {{  `${item.giftData.receiver.userName} ` }}</span>
        <span class="gift-name" :style="{color: getGiftNameColor()}"> {{  `${getGiftName(item.giftData)} ` }}</span>
        <img class="text-img" :src="item.giftData.src" />
        <span class="gift-count"> x {{ item.giftData.count }}</span>
      </span>
    </span>
  </span>
</template>

<script setup lang="ts">
import { useI18n } from '../../../locales';
import { useGiftList } from '../../Gift/useGiftList';
import { decodeMessageText } from '../util';

const { getGiftName, isSelfSend, getGiftNameColor } = useGiftList();
const { t } = useI18n();
const props = defineProps(['data']);

const handleTextMessageShowContext = (text: string) => decodeMessageText(text);
</script>

<style lang="scss" scoped>
.text-img {
  width: 20px;
  height: 20px;
  vertical-align: middle;
}

.gift-sender, .gift-receiver {
  color: #769EE2;
}

.gift-name {
  color: #E4E97C;
}
</style>  