<template>
  <div class="emoji-tool">
    <svg-icon
      :icon="EmojiIcon"
      class="emoji-icon"
      @click.stop="handleEmojiToobar"
    />
    <div
      v-show="showEmojiToolbar"
      v-click-outside="handleClickOutsideEmojiToobar"
      class="emoji-list"
    >
      <div
        v-for="(childrenItem, childrenIndex) in emojiList"
        :key="childrenIndex"
        class="emoji-item"
        @click="chooseEmoji(childrenItem)"
      >
        <img :src="emojiBaseUrl + emojiMap[childrenItem]" />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { emojiBaseUrl, emojiMap, emojiList } from '../util';
import SvgIcon from '../../common/base/SvgIcon.vue';
import EmojiIcon from '../../common/icons/EmojiIcon.vue';
import vClickOutside from '../../../directives/vClickOutside';
import { useI18n } from '../../../locales';

const { t } = useI18n();
const emit = defineEmits(['choose-emoji']);
const showEmojiToolbar = ref(false);
const chooseEmoji = (itemName: string) => {
  const emojiInfo = t(itemName);
  emit('choose-emoji', emojiInfo);
};
const handleEmojiToobar = () => {
  showEmojiToolbar.value = !showEmojiToolbar.value;
};
const handleClickOutsideEmojiToobar = () => {
  if (showEmojiToolbar.value) {
    showEmojiToolbar.value = false;
  }
};
</script>

<style lang="scss" scoped>
@import "../../../assets/style/variables.scss";

.tui-theme-white .emoji-list {
  --emoji-box-shadow: 0px 2px 4px -3px rgba(32, 77, 141, 0.03),
    0px 6px 10px 1px rgba(32, 77, 141, 0.06),
    0px 3px 14px 2px rgba(32, 77, 141, 0.05);
}

.tui-theme-black .emoji-list {
  --emoji-box-shadow: 0px 8px 40px 0px rgba(23, 25, 31, 0.6),
    0px 4px 12px 0px rgba(23, 25, 31, 0.8);
}

.emoji-tool {
  .emoji-icon {
    cursor: pointer;
  }

  .emoji-list {
    position: absolute;
    bottom: 5rem;
    left: 0;
    display: flex;
    flex-wrap: wrap;
    gap: 5px;
    width: 100%;
    height: 204px;
    padding: 10px;
    overflow-y: auto;
    background-color: var(--background-color-8);
    border-radius: 8px;
    box-shadow: var(--emoji-box-shadow);

    &::-webkit-scrollbar {
      display: none;
    }

    .emoji-item {
      &:hover {
        cursor: pointer;
      }
    }

    img {
      width: 23px;
      height: 23px;
    }
  }


  @media screen and (width < $h5Breakpoint) {
    .emoji-list {
      bottom: 3rem;
      left: 0;
      width: 16rem;
      height: 9rem;
    }
  }
}
</style>