<template>
  <div class="tui-share-link-button">
    <SvgIcon class="svg-icon" :icon="ShareLinkIconH5" @click="handleCopyShareLink" />
  </div>
</template>

<script lang="ts" setup>
import useRoomInfo from '../RoomHeader/RoomInfo/useRoomInfoHooks.ts';
import SvgIcon from '../common/base/SvgIcon.vue';
import TUIMessage from '../common/base/Message/index';
import ShareLinkIconH5 from '../common/icons/ShareLinkIconH5.vue';
import { useI18n } from '../../locales/index.ts';

const { onCopy } = useRoomInfo();
const { t } = useI18n();

const handleCopyShareLink = () => {
  try {
    const href = location.href;
    const regExp = new RegExp(
      '^https?://.*live[?]roomId=[0-9A-z!#$%()+-:;<=.>?@\\[\\]^_{}|~]+'
    );
    const hasShareLink = href.match(regExp);
    if (hasShareLink) {
      onCopy(hasShareLink[0]);
    }
  } catch (error) {
    TUIMessage({
      type: 'error',
      message: t('Copy share link failure')
    })
  }
};
</script>

<style lang="scss" scoped>
.tui-share-link-button {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 2rem;
  height: 2rem;
  border: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 50%;
  background-color: rgba(0, 0, 0, 0.25);
  cursor: pointer;
}
</style>