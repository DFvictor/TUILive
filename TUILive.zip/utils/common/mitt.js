import Mitt from 'mitt';
export default new Mitt();
